package day05;

import java.util.HashSet;
import java.util.Set;

/*
集合： set
 1. 不能有相同的元素,无序的
 2. Set是Interface, HashSet、 TreeSet是典型的实现类。
 3. HashSet 按Hash算法来存储元素。TreeSet是按照树来存储元素
 4. HashSet 用的比较多
 */
public class Demo04 {
    public static void main(String[] args) {
        Set<String> names = new HashSet<>();
        names.add("Tom");
        names.add("lily");
        names.add("wangwu");
        //names.add("Tom");   // 不能添加重复的元素
        System.out.println(names);

        // 删除元素 remove
        // 不能修改元素，没有set、get方法
        // 获取大小也是size
        // 包含 contains
        // 遍历 for 、 foreach
        names.remove("wangwu");
        System.out.println(names.size());
        System.out.println(names.contains("lily"));
        for (String name : names) {
            System.out.println(name);
        }


    }
}
