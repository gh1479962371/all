package day05;

/*
异常处理：try-catch-finally (同Python中的try-except-finally)  throw throws
 */
public class Demo01 {
    public static void main(String[] args) {
        String s = "ATGB";
        // 同Python中lower：变成小写
        try {
            float a = 10/0;
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage()); //e.getMessage()是异常信息
            e.printStackTrace();  // 打印调用栈（函数之间的调用关系）
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println(s.toLowerCase());
            System.out.println("执行结束！");
        }
    }
}
class Student {
    String name;
    char gender;

    // 使用throws声明抛出一个异常，使用throws声明抛出一个异常
    // throw是放到方法体中的，使用throw抛出一个异常
    public void setGender(char gender) throws Exception {
        if(gender=='男' || gender == '女') {
            this.gender = gender;
        } else {
            System.out.println("输入的参数有误！");
            Exception exp = new Exception("性别必须是男或者女");
            throw exp;  // 使用throw抛出一个异常
        }
    }

    public static void main(String[] args) /*throws Exception */ {
        Student student = new Student();
        try {
            student.setGender('人');
        } catch (Exception e) {
            e.printStackTrace();
            /*
            调用栈：
                at day05.Student.setGender(Demo01.java:34)
	            at day05.Student.main(Demo01.java:42)
             */
        }
    }
}
