package day05;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

/*
包装类：基本类型包装成引用类型（对象）
每个基本类型都有一个包装类。
int Integer
byte Byte
float Float
double Double
char Character
short Short
long Long
boolean Boolean

包装类的作用： 1.提供了一些实用的方法   2.集合中不允许基本类型，比如存放数字时，要用包装类
 */
public class Demo02 {
    public static void main(String[] args) {
        Integer a = 10;
        Integer b = new Integer(34);
        int a1 = 23;
        Integer c = a + b;
        String d = "34";
        String d1 = "12352";

        // Integer.valueOf():表示将几进制的字符串数转成10进制后的Integer包装类（可自动转为int型）
        // Integer.parseInt(): 表示将几进制的字符串数转成10进制后的int基本型（可自动转为Integer型）
        // a.intValue(): 表示将a的Integer型转为int型，（可不用，能自动转换）
        // a.toString(): 表示将包装类（引用类）转换为字符串型
        System.out.println("================================================");
        System.out.println(Integer.valueOf(d1,16));
        Integer e = Integer.valueOf(d);  // 字符串转整数
        int e2 = e.intValue();
        System.out.println(e);

        int f = Integer.parseInt("34");  //字符串转整数
        System.out.println(f);
        System.out.println(Integer.parseInt("34", 11));  // 34是11进制的数,转成10进制
        System.out.println(Integer.parseInt("34EF", 16)); // 34EF是16进制的数，转成10进制

        System.out.println(Integer.toHexString(100));  // 十进制转十六进制
        System.out.println("十进制转二进制：" + Integer.toBinaryString(100));  // 十进制转二进制
        System.out.println("十进制转八进制" + Integer.toOctalString(100));   //十进制转八进制

        int num1 = 10;
        int num2 = 0b11101101;  //二进制数，前面加0b
        int num3 = 01237;       // 八进制数，前面加0
        int num4 = 0x123ef;     // 十六进制数，前面加0x

        System.out.println("八进制转二进制" + Integer.toBinaryString(0x1FF));  // 八进制转二进制

        System.out.println("==============分割线=================");
        System.out.println(oct2dec("12345"));  // 边界内的值
        System.out.println(oct2dec("00000"));  // 最小边界值
        System.out.println(oct2dec("77777"));  // 最大边界值
        System.out.println(oct2dec("a1234"));  // 非法的八进制，报错
        System.out.println(oct2dec("1234"));   // 长度＜5，报错
        System.out.println(oct2dec("123456")); // 长度>5,报错
        System.out.println(oct2dec(null));     // 空值
        System.out.println(oct2dec("+7777"));  // 正数
        System.out.println(oct2dec("-7777"));  // 负数

        System.out.println("===================再分割线========================");
        System.out.println(evelen2dec("+21a45"));
        System.out.println(evelen2dec(("-25214")));
        System.out.println(evelen2dec("251a7"));
        System.out.println(evelen2dec("-00000"));
        System.out.println(evelen2dec("00000"));
        System.out.println(evelen2dec("77777"));
        System.out.println(evelen2dec("+77777"));
        System.out.println(evelen2dec("21b52"));
        System.out.println(evelen2dec("123"));
        System.out.println(evelen2dec("+22a"));
        System.out.println(evelen2dec("452121"));
        System.out.println(evelen2dec("-251254"));
        System.out.println(evelen2dec(null));
        System.out.println(evelen2dec("21"));
        System.out.println(evelen2dec(""));
        // 拆箱：包装类转基本类
        // 装箱：基本类型转成包装类型
        int j = 10;
        Integer i = j;   //自动装箱
        Integer k = 10;
        int m = k;       // 自动拆箱


    }
// 2-39进制
    // 写一个函数，实现将一个五位的八进制数转成十进制数
    public static int oct2dec(String oct) {
        try {
            if (oct.length() != 5) {
                System.out.println("输入有误！");
                return -1;
            } else {
                return Integer.parseInt(oct, 8);
            }
        } catch (Exception e) {
                System.out.println("输入的数据不是八进制数字：" + e.getMessage());
                return -1;
        }
    }
    // 1. 写一个函数，实现将一个1~5位的十一进制数转成十进制数。如果前面带+/-，则去掉加减后支持1~5位。并写测试用例，测试该函数
    //    十一进制：0-9,a
    public static int evelen2dec(String evelen) {
        try {
            //if (evelen.matches("^[+, -].*")) {
            if (evelen.startsWith("+") || evelen.startsWith("-")) {
                if (evelen.length() > 6) {
                    System.out.println("输入有误！");
                    return -1;
                } else {
                    return Integer.parseInt(evelen, 11);
                }
            } else {
                if (evelen.length() > 5) {
                    System.out.println("输入有误！");
                    return -1;
                } else {
                    return Integer.parseInt(evelen, 11);
                }
            }
        } catch (Exception e) {
            System.out.println("输入的数据不是十一进制数字：" + e.getMessage());
            return  -1;
        }
    }
}