package day05;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
Map（接口类） 映射 key : value
1. HashMap 、 TreeMap、 LinkedHashMap、 properties是Map的实现类
2. HashMap、 Properties（*.ini)->读写文件的  是比较常用的
 */
public class Demo05 {
    public static void main(String[] args) {
        int t = 123;
        System.out.println(t);
        // 一个是key的类型，一个是value的类型
        Map<String, String> maps = new HashMap<>();
        // 添加元素
        maps.put("CNY", "人民币");
        maps.put("USD", "美元");
        maps.put("JPY", "日元");
        maps.put("HKD", "港元");
        // 修改
        maps.put("CNY", "Chinese Yuan");
        // 取
        System.out.println(maps.get("CNY"));
        // 删除 remove
        // 大小 size
        // 包含 containsKey   containsValue
        System.out.println(maps.containsKey("USD"));
        System.out.println(maps.containsValue("韩元"));
        System.out.println(maps.size());
        System.out.println(maps.remove("HKD", "港元"));
        maps.remove("JPY");
        System.out.println(maps);

        // 遍历： 根据key获取所有的value
        Set<String> keys = maps.keySet();  //所有的key
        System.out.println("=====================分割线======================");
        System.out.println(maps.keySet());
        for(String key : keys) {
            System.out.println("key:" + key + ", value:" + maps.get(key));
        }
    }
}
