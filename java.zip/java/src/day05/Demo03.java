package day05;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;  //java.util 工具包

/*
列表： List   (是一种可扩容的数组）
 1. 特点：有序、可变、元素可以重复
 2. List是Interface，无法实例化，ArrayList、LinkedList是他的实现类
    ArrayList类似于可变长度的数组
    LinkedList 链表，查找元素效率高。
 */
public class Demo03 {
    public static void main(String[] args) {
        // 定义一个列表，<String>表示列表中的元素的类型
        List<String> names = new ArrayList<>();
        // 列表的常用操作：增删改查，排序
        names.add("Tom");
        names.get(1);
        names.add("Lily");
        System.out.println(names);
        int[] arrs = {1,2,3,4};
        String name = names.remove(0);  // 根据索引号删除,返回删除的元素的值
        System.out.println(name);
        boolean b = names.remove("Lily"); // 根据元素值删除，返回布尔值，（是否删除成功）
        System.out.println(b);

        names.add(0,"tom");
        //names.set(0, "TOM");    // 索引存在的情况下才能使用set修改、get获取，否则报错
        //System.out.println(names.get(0));
        names.add(0,"TOM");
        System.out.println(names);

        System.out.println(names.size());   // 列表长度
        System.out.println(names.contains("tom"));   // 是否包含某个元素

        // 遍历列表(for、 foreach)
        for (String n : names) {
            System.out.println(n);
        }
        for (int i = 0; i < names.size(); i++) {
            System.out.println(names.get(i));
        }

        // List<int>   基本类型无法放入列表
        // 1~ 100放入一个列表，遍历将值打印到一行，用逗号分隔。
        List<Integer> datas = new ArrayList<>();
        String s = "";
        for (int i = 1; i <= 100; i++) {
            datas.add(i);
            s = s + i + ",";  // 列表转字符串
        }
        System.out.println(datas);
        System.out.println(s);

        Students wangwu = new Students("王五", 68.3F);
        Students lisi = new Students("李四", 85F);
        Students zhangsan = new Students("张三", 92.5F);

        List<Students> students = new ArrayList<>();
        students.add(wangwu);
        students.add(lisi);
        students.add(zhangsan);
        System.out.println(students);    // 内存地址
        // 遍历列表
        for(Students stu : students) {
            System.out.println(stu.getName() + stu.getScore());
        }
        Students[] aa = {wangwu, lisi, zhangsan};   // 数组也可以存放Students的对象

        List<Integer> dds = Arrays.asList(1,2,3,4,5,6);   // 数组转换为列表
        System.out.println(dds);

        Integer[] sss = (Integer[]) dds.toArray();   //列表转数组
        System.out.println(Arrays.toString(sss));
        List<Students> students2 = Arrays.asList(wangwu, zhangsan, lisi);   //数组转列表

    }
}
// 新建一个学生的类，name、score、实例化几个学生，并加入列表中
class Students {
    private String name;
    private float score;

    public Students(String name, float score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }
}
