package day05;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/*
Collections 集合工具类：max、min、sort、binarySearch
 */
public class Demo06 {
    public static void main(String[] args) {
        List<String> ss = Arrays.asList("pig", "cat", "dog", "bird", "fish");

        String max = Collections.max(ss);
        System.out.println(max);

        System.out.println(Collections.min(ss));
        Collections.sort(ss);
        System.out.println(ss);
        System.out.println(Collections.binarySearch(ss, "pig"));
        Collections.shuffle(ss);  // 乱序
        System.out.println(ss);
    }
}    
