package day08;

import com.sun.deploy.security.BadCertificateDialog;
import com.sun.xml.internal.ws.addressing.WsaActionUtil;

import java.util.Arrays;
import java.util.Date;
import java.util.StringJoiner;

/*
字符串
String：       字符串常用操作
StringBuilder: 字符串连接  对象.append()
StringJoiner：  字符串拼接  对象.add()
 */
public class Demo02 {
    public static void main(String[] args) {
        String s1 = "abc";  // 常用
        String s2 = new String("abc");   // 不常用
        // 字符串判断是否相等，要用equals方法，不能用==， ==比较的是内存地址，equals比较得是内容
        System.out.println(s1 == s2);
        System.out.println(s1.equals(s2));

        // chartAt(): 获取某个位置上的字符
        System.out.println(s1.charAt(1));
        // contains(): 是否包含某个子串
        System.out.println(s1.contains("bc"));
        // toLowerCase toUpperCase  转成小写和大写
        System.out.println(s1.toUpperCase());
        System.out.println(s1);   // 转完大写小后本来的变量名的大小未变
        System.out.println(s1.toUpperCase().toLowerCase());
        // subString
        s1 = "hello, this is a java file";
        String s3 = s1.substring(0,6);  // 其实索引，结束索引(不包含结束索引的内容）
        System.out.println(s3);
        String s4 = s1.substring(7);  //一个参数表示起始的位置，一直取到最后
        System.out.println(s4);
        // indexOf("")  lastIndexOf("")  获取字符在字符串中的索引
        int a = s3.indexOf(" ");
        int b = s3.lastIndexOf(" ");
        System.out.println(a);
        System.out.println(b);

        // 练习：输入一个路径，E:\LearnJava\src\day08\Demo02.java
        // 取后缀名 java
        // 取文件名 Demo02.java
        String path = "E:\\workspace\\java\\src\\day08\\Demo02.java";
        System.out.println(path.substring(path.lastIndexOf(".") + 1));
        System.out.println(path.indexOf("."));
        System.out.println(path.lastIndexOf("."));
        System.out.println(path.substring(path.lastIndexOf("\\") + 1));

        // +
        String x = "Hello";
        String y = "world";
        String z1 = x + y;
        String z2 = x.concat(y);
        System.out.println(z1);
        System.out.println(z2);
        // 拼一个字符串：1,2,4.。。。10000，计算耗时
        String str = "";
        long begin = new Date().getTime();
        for(int i = 1; i <= 10000; i++) {
            str += i + ",";  // 可以不用写String.valueOf
        }
        long end = new Date().getTime();
        System.out.println(str);
        System.out.println("耗时：" + (end - begin));

        // 设计大量字符串拼接的时候，使用StringBuild，效率高，占用内存小
        StringBuilder sb = new StringBuilder();
        begin = (new Date()).getTime();
        for (int i= 1; i<=10000; i++) {
            sb.append(i);
            sb.append(",");
        }
        end = (new Date()).getTime();
        System.out.println(str);
        System.out.println("耗时：" + (end - begin));

        /*
        + 拼接，每循环一次，生成一个临时的str变量放内存中，
        StringBuilder 不会生成临时变量
         */

        String filePath = "d:\\test\\aa\\bb\\cc.java";
        // 字符串分割(返回数组形式)
        String[] temp = filePath.split("\\\\");
        System.out.println(Arrays.toString(temp));

        // join 静态方法.第一个用来拼接的字符，第二个到最后个参数是可变的参数
        String tt = String.join("\\\\","d:","test","aa","bb","cc.java");
        System.out.println(tt);

        // 字符串分隔和拼接的功能很常见，java提供了专门用来拼接的类：StringJoiner
        StringJoiner sj = new StringJoiner(",","Hello","！");
        String[] names = {"Tom","Lily","Lucy"};
        // elements 要拼接的字符串数组
        for(String name : names) {
            sj.add(name);
        }
        System.out.println(sj);
        //字符串比较
        System.out.println("aaa".equals("aaa"));
        System.out.println("aaa".equalsIgnoreCase("aAA"));
    }
}
