package day08;

import static org.junit.jupiter.api.Assertions.*;

class Demo03Test {

    @org.junit.jupiter.api.Test
    void isTriangle() {
        Demo03 test = new Demo03();
        // 失败的地方中断，之后的不再执行
        assertEquals("一般三角形",Demo03.isTriangle(7,8,9));
        assertEquals("等边三角形",Demo03.isTriangle(1,1,1));
        assertEquals("直角三角形",Demo03.isTriangle(3,4,5));
        assertEquals("等腰三角形",Demo03.isTriangle(3,2,3));
        assertEquals("参数错误",Demo03.isTriangle(0,2,3));
        assertEquals("不是三角形",Demo03.isTriangle(2,3,1));
    }
}