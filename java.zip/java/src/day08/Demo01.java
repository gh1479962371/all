package day08;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/*
实用类
Math： 常用的数学运算方法， PI
Random: SecureRandom: 生成随机数（开发的代码里，不允许使用Random。要用SecureRandom
Date： 日期的类（1、写日志文件，拿当前时间作为文件名 2、把当前时间记录到日志中 3、 代码中加等待时间）
 */
public class Demo01 {
    public static void main(String[] args) throws InterruptedException {
        Random random = new Random();
        for(int i = 0; i < 10; i++) {
            // 伪随机数，种子+算法，Random是拿当前时间作为种子，SecureRandom是用临时文件大小，线程休眠时间作为种子
            System.out.println(random.nextInt()); // int 范围内的随机数
            System.out.println(random.nextInt(10)); // 0~10之间的数
            System.out.println(random.nextFloat());  // 0~1之间的小数
        }
        SecureRandom secureRandom = new SecureRandom();
        for (int i = 0; i < 10; i++) {
            System.out.println(random.nextInt()); // int 范围内的随机数
            System.out.println(random.nextInt(10)); // 0~10之间的数
            System.out.println(random.nextFloat());  // 0~1之间的小数

        }
        System.out.println("==================分割线==============");
        Date date = new Date();
        System.out.println(date);   //获取当前日期加时间Thu Nov 05 09:54:36 GMT+08:00 2020

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //新建一个格式
        System.out.println(sdf.format(date));

        System.out.println(date.getTime());  //把时间改为时间戳，开始时间1970-1-1 8:00 0

        long begin= (new Date()).getTime();
        Thread.sleep(5000);   // 等待5秒
        long end = (new Date()).getTime();
        System.out.println("耗时：" + (end - begin));
    }
}
