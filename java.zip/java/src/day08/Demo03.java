package day08;

/*
单元测试：是动态测试。
白盒测试：能看到代码逻辑。
一般有开发来做，有一些公司是由测试来做。
Junit，java中的单元测试框架。
 */
public class Demo03 {
    // 是否三角形
    // 判定覆盖（覆盖度比较弱）：判定!(a+b > c && a+c > b && b+c > a)，每个判定true/false至少都覆盖一次
    // 条件覆盖（覆盖度比较弱）：一个判定点包含一个或者多个条件，这些条件之间有逻辑关系，条件a<0 ,每个条件的true/false至少覆盖一次
    // 路径（分支）覆盖：每条可能路径至少覆盖一次 （基于流程图，覆盖每条可能的路径）
    public static String isTriangle(int a, int b,int c) {
        if (a <= 0 || b<= 0 || c <= 0) {
            return "参数错误";
        }
        if (!(a+b > c && a+c > b && b+c > a)) {
            return "不是三角形";
        }
        else if (a == b && a== c) {
            return "等边三角形";
        }
        else if (a == b || b == c || a == c) {
            return "等腰三角形";
        }
        else if (a * a + b * b == c * c ||a * a + c * c == b * b||b * b + c * c == a * a) {
            return "直角三角形";
        } else {
            return "一般三角形";
        }
    }
}
