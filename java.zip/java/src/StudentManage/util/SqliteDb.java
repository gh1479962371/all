package StudentManage.util;

import StudentManage.model.Student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
sqlite 相关的操作
 1.连接数据库
 2.执行sql语句
 3.断开连接
 */
public class SqliteDb {
    Connection conn;
    /*
    连接数据库：通过驱动连接，每种类型的数据库有对应的驱动，驱动的版本与数据库版本有对应关系
    驱动是一个jar包下载地址：https://mvnrepository.com/
     */
    private void connect() {
        String JDBC_DRIVER = "org.sqlite.JDBC";  // 常量：驱动的名字
        String JDBC_URL = "jdbc:sqlite:student.db";  // 常量：数据库的访问路径

        try {
            //加载驱动
            Class.forName(JDBC_DRIVER);
            //连接数据库
            conn = DriverManager.getConnection((JDBC_URL));
            System.out.println("连接数据库成功！");
        } catch(Exception e) {
            System.out.println("连接数据库失败，异常信息：" + e.getMessage());
        }
    }

    /*
    断开数据库连接
     */
    private void close() {
        try {
            conn.close();
        } catch (Exception e) {
            System.out.println("断开数据连接失败，异常信息：" + e.getMessage());
        }
    }

    /*
    执行增删改类的sql，返回成功/失败
     */
    private boolean execute(String sql) {
        try {
            Statement statement = conn.createStatement();
            statement.execute(sql);   // 执行sql
           int count = statement.getUpdateCount();  // 获取影响了多少数据
            statement.close();
            System.out.println("执行sql语句：" + sql + "," + count + "条记录被更新。");
            return count >= 1;  // 执行成功时，至少1条记录被更新
        } catch (Exception e) {
            System.out.println("执行sql语句异常，异常信息：" + e.getMessage());
        }
        return false;
    }
    /*
    执行查询类的sql，返回表信息。
     */
    private List<Student> executeQuery(String sql) {
        List<Student> students = new ArrayList<>();
        try {
            Statement statement = conn.createStatement();
            boolean b =statement.execute(sql);   // 执行sql,execute如果结果是ResultSet(不管有无结果），则返回true
            if (b) {
                ResultSet rs = statement.getResultSet();
                if (rs != null) {
                    while (rs.next()) {
                        String id = rs.getString("id");  // 根据列表获取每行该列的值
                        String name = rs.getString("name");
                        String gender = rs.getString("gender");
                        String age = rs.getString("age");
                        String phone = rs.getString("phone");
                        String classes = rs.getString("classes");
                        // (String id, String name....)
                        Student stu = new Student(id, name, gender, age, classes, phone);
                        students.add(stu);
                    }
                }
            }
            System.out.println("执行sql语句：" + sql + "共查询到数据：" + students.size());
            statement.close();
        } catch (Exception e) {
            System.out.println("执行sql语句异常，异常信息：" + e.getMessage());
        }
        return students;
    }

    /*
    初始化数据库
     */
    public static void initTable() {
        SqliteDb db = new SqliteDb();
        db.connect();
        db.execute("create table if not exists student (" +
                "id carchar(32) primary key, " +
                "name varchar(10), " +
                "classes varchar(10)," +
                " age varchar(8), " +
                "gender varchar(2), " +
                "phone varchar(16))");
        db.close();
    }
    /*
    添加学生
    好处：1.调用简单
         2.屏蔽了sql数据库，如果后续数据库变更，只需要修改这一个文件
     */
    public static boolean addStudent(Student student) {
        String id = student.getId();
        String name = student.getName();
        String gender = student.getGender();
        String phone = student.getPhone();
        String classes = student.getClasses();
        String age = student.getAge();
        SqliteDb db = new SqliteDb();
        db.connect();
        boolean b = db.execute("insert into student  " +
                "values ('" + id + "','"+ name +"','"+ classes +"', '"+ age+ "', '" + gender + "', '"+ phone + "');");
        db.close();
        return b;
    }
    public static boolean deleteStudent(String name) {
        SqliteDb db = new SqliteDb();
        db.connect();
        boolean b = db.execute("delete from student where name = '"+ name + "';");
        db.close();
        return b;
    }
    /*
    查询所有
     */
    public static List<Student> queryStudent() {
        SqliteDb db = new SqliteDb();
        db.connect();
        List<Student> students = db.executeQuery("select * from student;");
        db.close();
        return students;
    }
    /*
    根据名字模糊查询
     */
    public static List<Student> queryStudent(String name) {
        SqliteDb db = new SqliteDb();
        db.connect();
        List<Student> students = db.executeQuery("select * from student where name like '%" + name + "%';");
        db.close();
        return students;
    }
    /*
    List转二维数组
     */
    public static String[][] list2Arrays(List<Student> students ) {
        String[][] res = null;
        if(students.size() > 0) {
            // 数组初始化的时候，需要给定长度。
            res = new String[students.size()][6];
            for(int i = 0; i < students.size(); i++) {
                Student stu = students.get(i);
                res[i][0] = stu.getId();
                res[i][1] = stu.getName();
                res[i][2] = stu.getGender();
                res[i][3] = stu.getAge();
                res[i][4] = stu.getClasses();
                res[i][5] = stu.getPhone();
            }
        }
        return res;
    }

    // 测试代码：用完可以删掉
    public static void main(String[] args) {
        initTable();
        //添加学生
        Student stu1 = new Student("1110","学生a", "女","18","十班", "1234521212");
        Student stu2 = new Student("1111","学生b", "女","18","十班", "1234521212");
        Student stu3 = new Student("1112","学生c", "女","18","十班", "1234521212");
        addStudent(stu1);
        addStudent(stu2);
        addStudent(stu3);
        deleteStudent("学生c");
        queryStudent();
        queryStudent("学生a");

    }
}
