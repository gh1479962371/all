package StudentManage.view;

import StudentManage.model.Student;
import StudentManage.util.SqliteDb;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

/*
添加页面：
1. 属性（Label、TextField）
2. 确定、取消
 */
public class AddView extends JFrame {
    JTextField nameField, ageField,classField, genderField, phoneField;
    public AddView() {
        this.add(northPanel(), BorderLayout.NORTH);
        this.add(southPanel(), BorderLayout.SOUTH);
        setTitle("增加学生");
        setBounds(650,300,500,300);
        setVisible(true);
    }

    /*
    标签和输入框
     */
    private JPanel northPanel() {
        JPanel jPanel =new JPanel();
        // 五个属性，每个属性一个标签，一个输入框
        GridLayout grid = new GridLayout(5,2);
        jPanel.setLayout(grid);

        JLabel nameLabel = new JLabel("姓名");
        jPanel.add(nameLabel);
        nameField = new JTextField();
        jPanel.add(nameField);

        JLabel ageLabel = new JLabel("年龄");
        jPanel.add(ageLabel);
        ageField = new JTextField();
        jPanel.add(ageField);

        JLabel classLabel = new JLabel("班级");
        jPanel.add(classLabel);
        classField = new JTextField();
        jPanel.add(classField);

        JLabel genderLabel = new JLabel("性别");
        jPanel.add(genderLabel);
        genderField = new JTextField();
        jPanel.add(genderField);

        JLabel phoneLabel = new JLabel("电话");
        jPanel.add(phoneLabel);
        phoneField = new JTextField();
        jPanel.add(phoneField);


        return jPanel;
    }

    /*
    OK 和 cancel按钮
     */
    private JPanel southPanel() {
        JPanel jPanel = new JPanel();
        JButton okButton = new JButton("确定");
        okButton.addActionListener(new OkAction());
        jPanel.add(okButton);

        JButton cancelButton = new JButton("取消");
        cancelButton.addActionListener(new CancelAction());
        jPanel.add(cancelButton);

        return jPanel;
    }

    private class OkAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // UUID Universally unique Identifier
            // 而标准的UUID格式为：xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx (8-4-4-4-12)
            // 其中每个 x 是 0-9 或 a-f 范围内的一个十六进制的数字
            String id = UUID.randomUUID().toString().replaceAll("-","");
            String name = nameField.getText();  //获取界面输入框的输入
            String age = ageField.getText();
            String classes = classField.getText();
            String gender = genderField.getText();
            String phone = phoneField.getText();
            Student stu= new Student(id, name, gender, age, classes, phone);
            boolean isSuccess = SqliteDb.addStudent(stu);  //将学生信息写入数据库
            if(isSuccess) {
                JOptionPane.showMessageDialog(null,"添加成功");
                dispose();  //关闭对话框
                //刷新表格
                // MainView类中修改为：public static JTable jTable;
                MainView.initTable(MainView.jTable,SqliteDb.queryStudent());
            }
        }
    }

    private class  CancelAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();   //关闭对话框
        }
    }
}
