package StudentManage.view;

import StudentManage.util.SqliteDb;
import com.sun.org.apache.bcel.internal.generic.ALOAD;
import sun.security.x509.IPAddressName;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteView extends JFrame{
    JTextField nameField;

    public DeleteView() {
        this.add(northPanel(), BorderLayout.NORTH);
        this.add(southPanel(), BorderLayout.SOUTH);
        setTitle("删除学生");
        setBounds(650,300,500,300);
        setVisible(true);
    }

    private JPanel northPanel() {
        JPanel jPanel = new JPanel();
        GridLayout grid = new GridLayout(1,2);
        jPanel.setLayout(grid);

        JLabel nameLabel = new JLabel("姓名");
        jPanel.add(nameLabel);
        nameField = new JTextField();
        jPanel.add(nameField);

        return jPanel;
    }

    private JPanel southPanel() {
        JPanel jPanel = new JPanel();
        JButton okButton = new JButton("确定");
        okButton.addActionListener(new OkAction());
        jPanel.add(okButton);


        JButton cancelButton = new JButton("取消");
        cancelButton.addActionListener(new CancelAction());
        jPanel.add(cancelButton);

        return jPanel;
    }

    private class OkAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name= nameField.getText();
            boolean isSuccess = SqliteDb.deleteStudent(name);
            if(isSuccess) {
                JOptionPane.showMessageDialog(null,"删除成功");
                dispose();
                MainView.initTable(MainView.jTable, SqliteDb.queryStudent());
            }
        }
    }

    private class CancelAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }
}
