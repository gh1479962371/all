package day03;

/*
static
    1. 修饰方法，静态方法，例如：main方法
    2. 修饰变量
    3. 修饰类
 */
public class Demo04 {
    String name;   // 成员变量，有多少个实例，就会有多少份
    static String school;  // (类变量)静态变量：内存里面只有一份
    static int a;

    // 静态方法，static修饰
    public static void print(String s) {
        System.out.println(s + school);  // 静态方法访问不到成员变量
    }

    public void log(String s) {
        System.out.println(s + name + school);
    }

    public static void main(String[] args) {
        System.out.println(a + school);   //静态方法访问不到成员变量
        Demo04.print("hello world");  // 静态方法调用：类名.方法名
        Demo04 d = new Demo04();   // // 成员方法调用：实例化后-->> 实例.方法名
        d.log("hello java");   // 实例.方法名

        for (int i = 1; i <= 25; i++) {
            Voter temp = new Voter("选民" + i);
            temp.vote();
        }
        System.out.println("投票总数为：" + Voter.count);
    }
}
// 一群选民投票，每个人投一票，投票总数达到20，就停止投票
class Voter {
    String name;   //选民的名字，表示出不同的选民
    static int count;  // 投票总数

    public Voter(String name) {
        this.name = name;

    }

    // 投票
    public void vote() {
        if (count == 20) {
            System.out.println("投票已经停止！");
        } else {
            System.out.println(name + ", 谢谢投票！");
            count = count + 1;
        }

    }
}
