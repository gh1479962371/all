package day03;

/*
面向对象：Object Oriented Programming OOP
    把大象装进冰箱：
        大象: 大象.进入(冰箱)
        冰箱: 冰箱.开门()、 冰箱.关门()
        人:   人.打开(冰箱)、 人.操作(大象)、 人.关闭(冰箱)
    类(类型): 是一个抽象，具有相同属性和方法的一组对象的抽象集合。
    对象: 是具体的实例，是具体的一个人/物
面向过程：Procedure Oriented Programming POP
    最小单位是函数
    把大象装进冰箱： 1.打开冰箱门 2.把大象放入冰箱 3.把门关上。三个步骤封装成三个函数，按顺序调用。

 */
public class Demo01 {
    public static void main(String[] args) {
        // Student : 是一个类型，表示一类人
        // zhangsan: 是一个实例，表是一个具体的人。
        Student zhangsan = new Student();
        zhangsan.name = "张三";  //给属性赋值，实例.属性名
        zhangsan.age = 20;
        zhangsan.gender = '男';
        zhangsan.height = 188;
        zhangsan.weight = 180;

        zhangsan.learning();  // 调用方法，实例.方法名
        zhangsan.sleeping();
        zhangsan.info();
        zhangsan.eating("肉肉","饮料"); // 方法：参数、返回时

        // 再创建一个实例
        Student lisi = new Student();
        lisi.name = "李四";
        lisi.age = 22;
        lisi.gender = '男';
        lisi.height = 180;
        lisi.weight = 170;

        lisi.learning();
        lisi.sleeping();
        lisi.info();
        lisi.eating("米饭","茶");

        // 定义类，圆。circle
        // 属性：半径r、圆心
        // 行为：面积 area、周长 perimeter。
        // Math.PI
        System.out.println(String.format("这是一个小数，只保留小数点后两位：%.2f",11.3456));
        Circle circle = new Circle();
        circle.r = 2.5;
        System.out.printf("%.2f",circle.area());
        System.out.println();
        System.out.println(String.format("%.2f",circle.area()));
        System.out.println(String.format("%.2f",circle.perimeter()));

    }
}
/*
学生类：
属性：性别、年龄、身高、体重、班级  变量
行为：学习、吃饭、睡觉、打游戏  方法

 */
class Student {
    String name;
    char gender;
    int age;
    float height;
    float weight;

    public void learning() {
        System.out.println(name + "正在学习");
    }
    public void sleeping() {
        System.out.println(name + "正在睡觉");
    }
    // 参数类型、参数名，多个参数用,隔开
    public void eating(String rice, String soup) {
        System.out.println(name + "正在吃" + rice + "喝" + soup);
    }

    public void info() {   // 打印学生信息
        System.out.println("学生姓名：" + name + ", 性别：" + gender + ", 年龄" +
                + age + ", 身高：" + height + ", 体重:" + weight);
    }
}
// 定义类，圆。circle
// 属性：半径r、圆心
// 行为：面积 area、周长 perimeter。
class Circle {
    double r;
    double center;
    // public 公共
    // void 无返回值
    // area 方法名/函数名
    // ()括号内定义的参数
    // {} 方法体
    // 没有参数，没有返回值

    // 无参数，有double类型的返回值（有返回值类型必须return返回）
    public double area() {
       double area = Math.PI * r * r;
       return  area;
    }
    // 无参数，无返回值
    public void area1() {
        System.out.println(String.format("面积为：%.2f",Math.PI * r * r));  //保留两位小数
    }
    public  double perimeter() {
        double perimeter = 2 * Math.PI * r;
        return perimeter;
    }
    public void perimeter1() {
        System.out.println(String.format("周长为：%.2f",Math.PI * 2 * r));  //保留两位小数
    }
}
