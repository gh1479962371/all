package day03;

/*
方法：
    参数：参数可以是任意类型的，任意个
    返回值：任意类型的，或者void
    方法重载：一个类有重名的方法，但是参数个数、参数类型、参数顺序不一样。调用比较简单 例如 sout(System.out.println()
    可变参数： 可以是0个、1个、多个参数
 */

public class Demo02 {
    public static void main(String[] args) {
        // 方法重载
        System.out.println("");
        System.out.println(0);
        System.out.println(0.0);
        System.out.println(true);

        Demo02 d = new Demo02();
        System.out.println(d.add(1,2));
        System.out.println(d.add(10.0F, 11.0F));
        System.out.printf("%.2f",d.add(11.12,11.13,11.23));

        System.out.println("===============分隔符============");
        Demo02 number = new Demo02();
        int max1 = number.max(2,12);
        System.out.println(max1);
        float max2 = number.max(2.1F, 15.2F);
        System.out.println(max2);
        int max3 = number.max(12, 5, 6);
        System.out.println(max3);
        number.max(15, 2.25F, 2.258);

        d.print("1", "2", "3");
        d.print("helo", "java");

    }

    /**
     * 可变参数: 一个方法只能有1个可变参数，如果方法有多个参数，可变参数放最后
     * @param strs
     */

    public void print(String... strs) {
        for(String str : strs) {
            System.out.print(str + ",");
        }
        System.out.println();
    }
    // 加法的方法
    public int add(int a, int b) {
        System.out.println("int类型的加法");
        return a + b;
    }
    public float add(float a, float b) {
        System.out.println("float类型的加法");
        return a + b;
    }
    public double add(double a, double b, double c) {
        System.out.println("三个double类型的加法");
        return a +b +c;
    }

    /*
    1. 两个整数，求最大值
    2. 两个浮点数，求最大值
    3. 三个整数，求最大值
    4. 一个整数、一个float、一个double，求最大值
     */
    public int max(int a, int b) {
        return Math.max(a,b);
    }
    public float max(float a, float b) {
        return Math.max(a,b);
    }
    public int max(int a, int b, int c) {
        return Math.max(Math.max(a,b), c);
    }
    public void max(int a, float b, double c) {
        System.out.println(((a > b ? a : b) > c) ? (a > b ? a : b) : c);
    }

}
