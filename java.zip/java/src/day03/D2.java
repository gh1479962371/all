package day03;

import java.util.Arrays;

public class D2 {
    public static void main(String[] args) {
        int[] a = {5,2,4};
        Arrays.sort(a);
        System.out.println(a);

    }
}
