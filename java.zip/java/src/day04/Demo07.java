package day04;

public class Demo07 {
    public static void main(String[] args) {
        AlarmDoor door = new AlarmDoor();
        door.open();
        door.close();
        door.alarm();
        door.usb("正在充电");
    }
}

/*
门：抽象类，开门、关门两个方法
警报：接口类、报警的接口
防盗门：从门继承，实现了警报的功能。
 */
abstract class Door {
    public abstract void open();  //关门   //修饰必写，因为普通抽象类里可能含有普通方法和抽象方法
    public abstract void close(); //开门
}
interface Alarm {
    void alarm();  //报警功能   // 修饰可不写都是公共抽象的，因为接口类(特殊的抽象类)，只有抽象方法
}
interface Usb {
    void usb(String status);
    //boolean usb(String status, int a);   //可以有参数和返回类型
}

// 电脑，实现USB的功能
// 实现类
class Computer implements Usb {

    @Override
    public void usb(String status) {
        System.out.println("电脑传输数据");
        System.out.println("充电");
    }
}

// 防盗门，从门继承，同时实现警报的功能
// 实现类
class AlarmDoor extends Door implements Alarm,Usb {

    @Override
    public void open() {
        System.out.println("指纹校验通过，打开门");
    }

    @Override
    public void close() {
        System.out.println("关并锁门");
    }

    @Override
    public void alarm() {
        System.out.println("陌生人靠近，报警");
    }

    @Override
    public void usb(String status) {
        System.out.println("通过usb充电");
    }
}
class PuTongDoor extends Door {

    @Override
    public void open() {
        System.out.println("一推就开");
    }

    @Override
    public void close() {
        System.out.println("一推就关");
    }
}