package day04;

/*
继承：所有类的父类都是object
 */
public class Demo02 {
    public static void main(String[] args) {
        Dog wangcai = new Dog("旺财", 5, 100);
        System.out.println(wangcai.toString());
        wangcai.setName("旺财");   // 子类继承父类的属性和方法
        wangcai.setHealth(80);
        wangcai.setAge(5);
        System.out.println(wangcai.toString());

        Dog dog1 = new Dog("阿黄", 2, 85, "泰迪狗");
        System.out.println(dog1.toString());
    }
}

// 宠物类
class Pet {
    private String name;
    private int age;
    private int health; //健康度

    public Pet(String name, int age, int health) {
        this.name = name;
        this.age = age;
        this.health = health;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    @Override
    public String toString() {
        return "Pet{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", health=" + health +
                '}';
    }
}

// 宠物狗的类，从宠物类继承，继承使用extends关键字
// 子类继承父类的属性，方法，不继承父类的构造方法
class Dog extends Pet {

    private String strain = "牧羊犬";  // 品种

    public Dog(String name, int age, int health) {
        super(name, age, health);   //super表示父类，也叫superClass超类
    }
    // 重载构造方法
    public Dog(String name, int age, int health, String strain) {
        super(name, age, health);
        this.strain = strain;
    }

    public String getStrain() {
        return strain;
    }

    public void setStrain(String strain) {
        this.strain = strain;
    }

    @Override  // 重写：子类重写父类同名的方法
    public String toString() {
        return "Dog{" +
                "strain='" + strain + '\'' +
                "} " + super.toString();   // super.toString()调用父类的toString()方法
    }
}


