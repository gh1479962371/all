package day04;

import java.util.Arrays;

public class GaoHuan{
}

/**
 * 定义一个测试类TestTriangle，
 * main，测试isTriangle方法（边界值、等价类）。
 */
class TestTriangle {
    public static void main(String[] args) {
        double[][] arrs = {{1, 2, 0}, {1, 2, 4}, {2, 2, 3}, {2.22, 2.22, 2.22}, {2, 3, 4.2},
                {3, 4, 5}, {1,5.2,3.5},{2,5,3}, {2,8,12}};
        for (double[] arr : arrs) {
            Triangle triangle = new Triangle(arr);
            System.out.print(Arrays.toString(arr));
            triangle.isTriangle();
        }
    }
}
/**
 * 定义一个三角形类 Triangle，
 * 属性：a、b、c 三个边长
 * 方法：
 *  isTriangle() 判断三角形的类型（）
 *      1、一般、等边、等腰、直角、不是三角形
 *      2、参数做简单的检查，参数小于0，报错。
 */
class Triangle {
    double a;
    double b;
    double c;

    public Triangle(double arr[]) {
        this.a = arr[0];
        this.b = arr[1];
        this.c = arr[2];
    }

    public void isTriangle() {
        double t[] = {a,b,c};
        Arrays.sort(t);
        if (t[0] <= 0) {
            System.out.println("输入的数据有误！");
        } else if (t[0] + t[1] <= t[2]) {
            System.out.println("不是三角形");
        } else {
            if (t[0] == t[2]) {
                System.out.println("是等边三角形");
            } else if (t[0] * t[0] + t[1] * t[1] == t[2] * t[2]) {
                System.out.println("是直角三角形");
            } else if (t[0] == t[1] || t[1] == t[2]) {
                System.out.println("是等腰三角形");
            } else {
                System.out.println("是一般三角形");
            }
        }
    }
}


