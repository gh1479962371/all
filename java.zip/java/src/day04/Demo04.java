package day04;

import javafx.scene.shape.Circle;

/*
多态：多种形态。子类从父类继承，它既是子类的类型，也是父类的类型
 */
class Cat extends Pet {
    public Cat(String name, int age, int health) {
        super(name, age, health);
    }
}

public class Demo04 {
    // 宠物看病的方法
    public  static void master(Dog dog) {
        if(dog.getHealth() < 60) {
            System.out.println("吃药打针输液");
        } else {
            System.out.println("洗澡按摩");
            dog.setHealth(90);
        }
    }

    public static void master_shenyi(Pet pet) {
        if(pet.getHealth() < 60) {
            System.out.println("吃药打针输液");
        } else {
            System.out.println("洗澡按摩");
            pet.setHealth(90);
        }
    }
    public static void main(String[] args) {
        Dog dog = new Dog("小黄", 10, 20);
        master(dog);
        master_shenyi(dog);   // 子类可以作为父类型使用，可以看做特殊的父类，

        Pet cat = new Pet("小猫", 5, 85);
        // master(cat);  // 父类不能当子类去用
        master_shenyi(cat);
        Student st = new Student();

    }
}

class a {
    public static void main(String[] args) {
        Dog dog3 = new Dog("xiaohang", 12,30);
        Demo04.master(dog3);
        Cat cat1 =new Cat("xiaomao", 3,60);
        // Demo04.master(cat1);
        Demo04.master_shenyi(cat1);
    }
}
