package day04;

/*
抽象类:宠物类，狗是从宠物类继承，猫也是从宠物类继承，乌龟从宠物类继承
可以把宠物类定义成抽象类。
抽象类设计是为了继承而存在

接口（特殊的抽象类）
   List、Map是接口，接口对应的实现类ArrayList、LinkedList
 */
public class Demo05 {
    public static void main(String[] args) {
        // Animal animal = new Animal();  // 抽象类不能被实例化
        Animal animal = new Fish();   // 创建一个Fish，赋值给Animal
        Fish fish = new Fish();
    }
}

/*
抽象类：
 1.使用abstract修饰的类是抽象类，abstract修饰的方法是抽象方法。抽象方法：有方法的定义，没有实现
 */
abstract class Animal {            // 抽象类
    public abstract void func1();  // 抽象方法，只有方法的定义，没有实现

    public void func2() {          // 普通方法
        System.out.println("方法func2");
    } // 普通方法
}

class Fish extends Animal {

    @Override
    public void func1() {
        System.out.println("鱼儿在水中游");
    }
}