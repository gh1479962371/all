package day04;

/*
面对象的三大特点：封装、继承、多态
封装：把属性设置为private
 */
public class Demo01 {
    public static void main(String[] args) {
        Student zhangsan = new Student();
        zhangsan.name = "张三";  // 设置名字
        zhangsan.age = 20;
        zhangsan.gender = '男';
        // gender: 男、女
        zhangsan.gender = '鬼';
        System.out.println(zhangsan.toString());

        Student1 lisi = new Student1();
        lisi.setName("李四");   // 设置名字
        String name= lisi.getName();   // 获取名字
        System.out.println(name);
        lisi.setAge(22);
        int age = lisi.getAge();
        System.out.println(age);

        lisi.setGender('女');
        System.out.println(lisi.getGender());
        System.out.println(lisi.toString());
        lisi.setGender('鬼');
        System.out.println(lisi.getGender());
        System.out.println(lisi.toString());
    }
}

class Student {
    String name;
    int age;
    char gender;

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                '}';
    }

}
// 封装：把属性设置为private，对外提供public的get、set方法访问
// 实现细节封装在类的内部，调用者通过类提供的方法访问属性/数据，可给属性增加一些逻辑控制，避免一些不合理的操作
class Student1 {
    private String name;
    private int age;
    private char gender;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAge(int age) {
        if(age<=0 || age<= 150) {
            System.out.println("年龄有误，请重新设置！");
        } else {
            this.age = age;
        }
    }

    public int getAge() {
        return age;
    }

    public void setGender(char gender) {
        if(gender != '男' && gender != '女') {
            System.out.println("性别有误，请重新设置!");
        } else {
            this.gender = gender;
        }
    }
    public char getGender() {
        return gender;
    }
    @Override
    public String toString() {
        return "Student1{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                '}';
    }
}


