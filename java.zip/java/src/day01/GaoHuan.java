package day01;

import java.util.Scanner;

public class GaoHuan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        /* 1. 编写一个程序,为给定的年份找出其中国生肖值。(中国生肖基于12年一个周期)
                注:1900年属鼠,因为1900%12为4,则判定4为鼠年,依次类推。*/
//        a:
//        while (true) {
//            System.out.println("请输入年份：");
//            int year = scanner.nextInt() % 12;
//            switch (year) {
//                case 0:
//                    System.out.println("猴年");
//                    break a;
//                case 1:
//                    System.out.println("鸡年");
//                    break a;
//                case 2:
//                    System.out.println("狗年");
//                    break a;
//                case 3:
//                    System.out.println("猪年");
//                    break a;
//                case 4:
//                    System.out.println("鼠年");
//                    break a;
//                case 5:
//                    System.out.println("牛年");
//                    break a;
//                case 6:
//                    System.out.println("虎年");
//                    break a;
//                case 7:
//                    System.out.println("兔年");
//                    break a;
//                case 8:
//                    System.out.println("龙年");
//                    break a;
//                case 9:
//                    System.out.println("蛇年");
//                    break a;
//                case 10:
//                    System.out.println("马年");
//                    break a;
//                case 11:
//                    System.out.println("羊年");
//                    break a;
//                default:
//                    System.out.println("请输入正确的年份：");
//
//
//            }
//        }
        /* 2. 将百分制的学生成绩转成A/B/C/D等级制
                分数>=90：A
                90>分数>=70:B
                70>分数>=50:C
                分数<50:D */
//        while (true) {
//            System.out.println("请输入学生成绩");
//            double score = scanner.nextDouble();
//            if (score >= 90) {
//                System.out.println("成绩等级是：A");
//                break;
//            } else if (score >= 70) {
//                System.out.println("成绩等级是：B");
//                break;
//            } else if (score >= 50) {
//                System.out.println("成绩等级是：C");
//                break;
//            } else if (score < 50 & score >= 0) {
//                System.out.println("成绩等级是：D");
//                break;
//            } else {
//                System.out.println("数字不合法，请重新输入成绩!");
//            }
//        }
//


        /* 3.输入一个4位数的会员卡号，如果4个数的和为25，则该会员中奖。比如输入卡号6666，和为24. */
        try {
            System.out.println("请输入4位数的会员卡号：");
            int card = scanner.nextInt();
            if (card <= 0 | card / 10000 >0) {
                System.out.println("请输入正确的数字！");
            }
            else {
                int card1 = card % 10;
                int card2 = (card / 10) % 10;
                int card3 = (card / 100) % 10;
                int card4 = (card / 1000) % 10;
                int sum = card1 + card2 + card3 + card4;
                if (sum == 25) {
                    System.out.println("中奖了！");
                } else if (sum >= 0) {
                    System.out.println("未中奖...");
                }
            }
        }
        catch (Exception e) {
            System.out.println("输入类型有误！");
        }


    }
}
