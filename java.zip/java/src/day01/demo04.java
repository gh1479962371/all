package day01;

/**
 * Java: 注释、标识符、输入和输出、变量
 * Java数据类型：（1）8种基本类型：整形（byte、short、int、long), 浮点型（float、double）、字符型（char)、boolean类型
 *              （2）引用类型：类（class)、接口（interface）和数组（array）
 * Python可变数据类型：列表、字典、集合
 *       不可变数据类型：数值（int、float、double、bool）、元组。字符串
 */

public class demo04 {
    public static void main(String[] args){
        //1.整形（byte、short、int、long),取值范围不一样
        // byte 一个字节来表示，取值范围 -128 ~ 127
        byte b1 = -128;
        byte b2 = 127;
        // byte b3 = 255;   // 取值范围超出，系统会语法报错
        System.out.println(b1 + "," + b2);
        // short两个字节表示，取值范围：-2的15次方 ~ 2的15次方-1，-32768~32767
        short s1 = -32768;
        short s2 = 32767;
        System.out.println(s1 + "," + s2);
        // int 四个字节来表示，取值范围：-2的31次方 ~ 2的31次方-1，-2147483648 ~ 2147483647
        // 常用的类型
        int i1 = -2147483648;
        int i2 = 2147483647;
        System.out.println(i1 + "," + i2);
        // long 八个字节来表示,long类型的数字，后面加个L。取值范围：-2的63次方 ~ 2的63次方-1，-9223372036854775808 ~ 9223372036854775807L
        long long1 = -9223372036854775808L;
        long long2 = 2147483648L;   //大小写的L都可以，但是尽量不用小写l,因为和1比较相似，不方便识别
        System.out.println(long1 + "," + long2);

        // 浮点类型，float 4个字节，double 8个字节，浮点数字默认是double类型的，如果赋值给float。数字后面加F
        float f1 = 1123.13123F;
        double d1 = 1123.13123;
        System.out.println(f1 + "," + d1);

        // 字符类型，值使用单括号括起来，String 字符串类型，使用双拥好引起来。
        char c1 = '0';   // ASII码48
        char c2 = 'a';   // ASII码97
        System.out.println(c1 + "," + c2);
        System.out.println(c1 + c2);   // 不是0a,而是145，char类型实际存储得是整数（ASII)，输出ASII码相加的值
        char c3 = '\n';
        char c4 = '\t';   // 可以是转义字符

        // boolean取值true/false
        boolean bool1 = true;
        boolean bool2 = false;

        // 类型与类型之间的转换。除Boolean之外的7中类型间的转换。
        // 自动转换：小容量向大容量转换。 相当于小瓶水倒入大瓶子。 byte\char\short ---> int --->long --->float --->double
        // 强制转换：大容量向小容量转换。大瓶子水倒入小瓶子中。
        byte byte1 = 10;
        int int1 = 20;
        int int2 = byte1 + int1;   // byte1会自动转换为int类型，再于int1进行计算
        System.out.println(int2);

        long long3 = 1022222222223225445L;
        // 小容量与大容量运算时，自动把小容量的转换为大容量的在进行计算，最终结果是大容量类型的。
        long long4 = long3 + int1;  // int1会自动转换为long类型后，再与long3进行计算，最后结果是long类型的。
        // 强制转换，会导致溢出或者精度丢失
        int int3 = (int) (long3 + int1);   // (int)long3 + int1
        System.out.println(int3);    //-182439303
    }
}
