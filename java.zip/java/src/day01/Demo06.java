package day01;

/*
顺序结构
循环结构: while、for、do-while(python中没有）
分支结构：if-else、 switch(Python中没有）
 */

import java.util.Scanner;

public class Demo06 {
    public static void main(String[] args) {
        int age = 18;
        if (age >=18) {
            System.out.println("已经成年!");
        } else {
            System.out.println("未成年人！");
        }
        // elif（python中的写法）
        // else if
        //练习：计算狗的年龄，一只狗现在5岁，计算它相当于人类的多少岁
        //   狗的前两年相当于人类的10.5岁，之后每增加一年相当于增加四岁
        // 5岁狗 = 10.5 * 2 + 4 * 3 = 33岁。
        // 从键盘输入够的年龄，输出相当于人类的多少岁。
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("请输入狗的年龄：");
            int dogAge = scanner.nextInt();
            if (dogAge > 0 && dogAge <= 2) {
                System.out.println("相当于人类的年龄:" + dogAge * 10.5);
                break;  // continue
            } else if (dogAge > 2) {
                System.out.println("相当于人类的年龄：：" + (2 * 10.5 + (dogAge - 2) * 4));
                break;  // continue
            } else {
                System.out.println("狗尚未出生，请重新输入！");
            }
        }

        // switch-case 多分支的结构

         a : while (true) {
            System.out.println("请输入一个季节：");
            String season = scanner.next();
            switch (season) {    //case 是season可能的取值
                case "春季":    // case后面跟一个常量
                    System.out.println("春暖花开");
                    break a;
                case "夏季":
                    System.out.println("烈日炎炎");
                    break a;
                case "秋季":
                    System.out.println("秋高气爽");  // 如果没有break，一致执行后面的case，直到遇到break为止。
                    break a;
                case "冬季":
                    System.out.println("冬雪皑皑");
                    break a;
                default:
                    System.out.println("不认识的季节。");
            }
        }

        // 练习：输入一个月份，判断是哪个季节，11,12,1 冬季  2,3,4 春季 5,6,7 夏季 8,9,10 秋季
        System.out.println("请输入月份");
        int month = scanner.nextInt();
        switch (month){
            case 11 :
            case 12 :
            case 1 :
                System.out.println("是冬季");
                break;
            case 2:
            case 3 :
            case 4 :
                System.out.println("是春季");
                break;
            case 5 :
            case 6 :
            case 7 :
                System.out.println("是夏季");
                break;
            case 8 :
            case 9 :
            case 10 :
                System.out.println("是秋季");
                break;
            default:
                System.out.println("不认识的月份！");
                break;
        }
    }
}
