package day02;

import java.util.Arrays;
import java.util.Scanner;

public class GaoHuan {
    public static void main(String[] args) {
        // 1. 输出九九乘法表
        for(int i = 1; i < 10; i++) {
            for(int j = 1; j < i + 1; j++) {
                System.out.print(j + "x" + i + "=" + j * i +"\t");
            }
            System.out.println();
        }
        /* 2. 每次打印一个*，输出如下图案
                ******
                *****
                ****
                ***
                **
                *
         */
        for(char i = 0; i < 6; i++) {
            for(char j = 0; j < 6 - i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        // 3.定义一个学生成绩的数组，键盘录入10个学生的成绩，计算总成绩。
        Scanner scanner= new Scanner(System.in);
        int[] scores = new int[10];
        int sum = 0;
        for(int i = 0; i < 10; i++) {
            System.out.println("请输入第" + (i+1) + "个学生的成绩");
            int score = scanner.nextInt();
            scores[i] = score;
            sum += score;
        }
        System.out.println(Arrays.toString(scores));
        System.out.println("总成绩为：" + sum);

        // 输入三个学生三门课程的成绩，算出平均值，使用二维数组
//        Scanner scanner= new Scanner(System.in);
//        int[][] scores = new int[3][3];
//        int sum = 0;
//        for(int i = 0; i < 3; i++) {
//            System.out.println("请输入第" + (i+1) + "个学生的成绩");
//            for(int j = 0; j < 3; j++) {
//                int score = scanner.nextInt();
//                scores[i][j] = score;
//                sum += score;
//            }
//        }
//        System.out.println(Arrays.deepToString(scores));
//        System.out.println("总成绩为：" + sum);
    }
}
