package day02;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Scanner;

/**
 * 数组：同一类型的一组数据，使用一个名字访问。固定长度，有序排列的。
 */

public class Demo02 {
    public static void main(String[] args) {
        // 数组的定义方式一
        int[] ids;   // 数组的声明
        ids = new int[]{1001,1002,1003};   //数组的初始化，初始化的时候赋值

        System.out.println(ids[2]);   // 使用下标访问第二个元素，如果下标超过数组长度，会越界报异常java.lang.ArrayIndexOutOfBoundsException

        System.out.println(ids.length);  // 数组的长度

        //遍历数组：foreach循环，每次取一个数组的元素----自动生成这种形式（点击for高亮后点击蓝色字体）
        for (int id : ids) {
            System.out.println(id);
        }
        // 遍历数组，遍历索引，根据索引取元素
        for(int i = 0; i < ids.length; i++) {
            System.out.println(ids[i]);
        }

        // 数组的定义方式二
        int[] nums = new int[10];  //先声明一个数组，不赋值，10表示数组的长度
        // 不赋值的情况下，有默认的初始值，int类型的初始值是0; float是0.0
        for(int n: nums) {
            System.out.println(n);
        }

        // 数组的定义方式三
        int[] scores = {10,20,30,40,50,60,70};   // 长度是7的数组。不用写new int[],系统会自动推断类型

        // String数组，存放人名
        String[] names = {"aa","bb","cc","dd"};
        System.out.println(names);  // 内存地址，数组第一个元素在内存中的位置
        for(String name : names) {
            System.out.println(name);
        }
        String[] ns = new String[10];
        // String是引用类型，引用类型的默认初始值是null
        // int/float/double/char 是基本类型，基本类型的初始值是0值
        for(String n : ns) {
            System.out.println(n);   // 打印出来是null
        }

        // 找出数组中最大值
        // 打擂的方式
        int[] scores2 = {10,20,30,40,50,60,70};
        int max = scores2[0];  //将数组中第一个元素设置为max
        for(int s : scores2) {  // 遍历数组中的每个元素
            if (s > max) {   // 如果s大于max
                max = s;    //将max替换
            }
        }
        System.out.println(max);

        String[] names2 = {"李四","张三","王五"};
        String min = names2[0];
        for(String name : names2) {
            if(name.compareTo(min) < 0) {
                min = name;
            }
        }
        System.out.println(min);
        System.out.println("AA".compareTo("AA")); //相等返回0
        System.out.println("AA".compareTo("AB")); // -1
        System.out.println("ZB".compareTo("BA")); // 24
        System.out.println("中国".compareTo("花朵")); // -13444
        char c = '中';
        char h = '花';
        System.out.println(c - h);
        System.out.println(c + h);

        //冒泡排序：由大到小排序
        System.out.println("------------------------------------------");
        int[] arr = {2,5,3,12,52,142,6,0,600,11};
        int n = arr.length;
        for(int i = 0; i < n - 1; i++) {
            for(int j = 0; j < n-1-i; j++) {
                if(arr[j] < arr[j + 1]) {
                    int t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
        for(int i : arr){
            System.out.print(i + " ");
        }

        // UTF-8 Unicode 世界所有的字符集
        // GBK GB2312中文字符集
//        public static  String stringToUnicode(String str) {
//            StringBuffer sb = new StringBuffer();
//            char[] c = str.toCharArray();
//            for(int i = 0; i < c.length; i++) {
//                sb.append("\\u" + Integer.toHexString(c[i]));
//            }
//            return Integer.parseInt(sb.toString());
//        }



    }
}
