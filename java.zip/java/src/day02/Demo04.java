package day02;

import com.sun.javaws.Main;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import org.w3c.dom.ls.LSOutput;

import java.util.Arrays;

/**
 * 二维数组[][]：可以看成一维数组，数组里面的元素还是数组。
 */
public class Demo04 {
    public static void main(String[] args) {
        // 数组有4个元素，每个元素是一个数组，里面有3个元素
        int[][] ids = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}, {10, 11, 12}};

        int[][] ids2 = new int[4][3];
        ids2 = new int[][]{{1, 2, 3}, {4, 5, 6}, {7, 8, 9}, {10, 11, 12}};
        /*
        1 2 3
        4 5 6
        7 8 9
        10 11 12
         */
        System.out.println(ids[3][2]);   // 12
        System.out.println(Arrays.toString(ids[3]));  // {10,11,12}

        // 遍历二维数组
        for(int i = 0; i < ids.length; i++) {
            for(int j = 0; j < ids[i].length; j++) {
                System.out.print(ids[i][j]);
            }
            System.out.println();
        }

        // 新建一个二维数组，里面存储人的信息，每个人的（姓名，年龄，身高，体重）
        String[][] info = {{"张三","12","120","20"},{"王五","13","130","30"},{"李四","14","140","40"}};
        // 遍历二维数组：foreach的方式
        for (String[] i : info) {
            System.out.println(Arrays.toString(i));
        }
        for (String[] i : info) {
            for (String j : i) {
                System.out.print(j + "\t");
            }
            System.out.println();
        }
    }
}
