package day02;

import java.util.Scanner;

/*
循环：for循环、while循环、do-while循环
循环包含四部分内容：初始化条件、循环条件、循环体、迭代条件
 */
public class Demo01 {
    int i;  //实例的属性   对象.i
    static int j;  //类的属性   Demo01.j

    public static void main(String[] args) {
        Demo01 dd = new Demo01();   //创建一个对象
        System.out.println(dd.i);

        for (int i = 0; i< 5 ;i++) {   //int i = 0 初始化条件；i<5 循环条件;i++ 迭代条件
            System.out.println("hello world");  //循环体
        }

        /*
        1.int i = 0 只执行一次
        2.i < 5 是不是成立，
        3.如果成立，执行循环体，否则跳出循环
        4.再去执行i++
         */

        // 打印1~100之间的偶数，for循环遍历
        for (int i = 2; i <=100;i=i+2) {
            System.out.print(i + ",");
        }
        System.out.println("\n");

        for (int i = 1; i<= 100; i++) {
            if (i % 2 == 0) {
                System.out.print(i + ",");
            }
        }
        System.out.println("");

        int k = 1;   //初始化条件
        while (k <= 100) {// 循环条件
            //循环体
            if (k % 2 == 0) {
                System.out.print(k + ",");
            }
            // 迭代条件
            k++;
        }
        System.out.println("");  // 换行

        // 1~ 100的和
        // ctrl+alt+L 格式化代码
        int s = 0;
        int i = 1;
        while (i <= 100) {
            s = s + i;    // 或者写成：s += i;
            i++;
        }
        System.out.println(s);

        long s1 = 1;
        i = 1;
        while (i <= 20) {
            s1 *=i;
            i++;
        }
        System.out.println(s1);

        // do-while 至少执行一次
        int x = 0;  //初始化条件
        s = 0;
        do {
            s = s + x;  //循环体
            x++;   //迭代条件
            System.out.println("do-while-1");
        } while(x <= -1);   //循环条件
        System.out.println(s);

        //*********** 8个
        //*********** 8个
        //*********** 8个
        //*********** 8个
        //*********** 8个
        //*********** 8个
        for(int j = 0; j<6;j++) {    // 打印6行星星
            for(i =1;i < 8;i++) {   // 每行8个星星
                System.out.print("*");
            }
            System.out.println();
        }

        for(int j = 0; j < 6; j++) {
            for(i = 0; i < j + 1; i++) {
                System.out.print("*");
            }
            System.out.println();
        }  // 圈复杂度（即嵌套深度）不能太高：1.执行效率低 2.代码逻辑复杂 3.维护不方便 4.圈复杂度有专门的静态检查工具

        // break: 跳出循环
        // continue: 跳出本次循环，执行下一次循环
        aaa:
        for(i = 1;i <= 4;i++) {
            for(int j = 1; j <=10; j++) {
                if(j % 4 ==0) {
                    //break label;   // 不写break后面的标识符，默认跳出最近的循环，（加上标识符跳出标识符下的所有循环）
                    continue aaa;  // 不写的话continue后面的标识符，默认继续执行最近的循环的下一次循环，（加标识符，继续执行标识符下的循环）
                }
                System.out.print(j);
            }
            System.out.println();
        }

        // 循环录入某个学生5门课程的成绩（可能是小数），计算平均分，如果录入的分数是负数，停止并提示错误
        //for循环实现
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入5门课程的成绩：");
        float total = 0;
        for ( i = 0; i < 5; i++) {
            float score = scanner.nextFloat();
            if(score < 0) {
                System.out.println("输入的成绩不合法，退出");
                break;
            } else {
                total = total + score;
            }
            if(i==4){
                System.out.println("总成绩为：" + total + ", 平均成绩为：" + total /5);

            }
        }

    }
}
