'''
class中的变量级别：
局部变量>成员变量>类变量
'''


class Student:
    # 类变量
    # 类变量和成员变量尽量不要使用相同的名字
    # 类的所有实例共享类变量
    name = 'Student'
    clazz = '测试36班'
    # count变量记录学生的数量
    count = 7

    def __init__(self, name):
        # 成员变量
        self.name = name
        # 局部变量
        Student.count += 1
        self.count += 1
        # count += 1


s1 = Student('Julia')
s2 = Student('Michael')

print(s1.name)  # 成员变量优先级高于类变量
print(s2.name)

print(Student.name)
print(s1.clazz)
print(s2.clazz)

s1.clazz = '开发36班'
print(s2.clazz)
print(s1.clazz)
Student.clazz = '测开36班'
print(s1.clazz)
print(s2.clazz)

s3 = Student('jack')
print(Student.count)
print(s3.count)
