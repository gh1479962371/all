s = 'a  bcd 11234 to m'
print(s.split(' '))
print(s.split('1'))