'''
异常处理
'''

# 异常处理机制
# 把有可能发生异常的代码放在try当中
try:
    print('你好')
    d = int(input("请输入下一个整数："))
    if d == 0:
        raise ZeroDivisionError('除数是0')  # 手动抛出一个异常
    r = 10 / d
    print("r=%d" % r)
# 当发生异常，执行except中的代码
# except：捕捉异常
# Exception:异常类型
# 如果有捕捉到多个异常类型，小类型在前面，大类型在后面
except ValueError as e:
    print('ValueError=', e)
except ZeroDivisionError as e:
    print('ZeroDivisionError=', e)
    # raise ZeroDivisionError('除数是0')
except Exception as e:
    print('Exception=', e)
# 放在finally中的代码无论是否发生异常，都会执行
finally:
    print('计算结束！')

print('今天是个好天气！')
