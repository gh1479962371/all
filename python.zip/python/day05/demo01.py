'''
获取对象信息
'''
import types

'''
type()
'''
# 获取对象类型
print(type(1234))
print(type('tom'))
print(type(abs))
print(type(1)==type(2))
print(isinstance(1,int))
print(type(1)==int)
print(type([1,2,3]))

def f():
    pass

print(type(f))
print(type(f)==types.FunctionType)

'''
isinstance()
'''
# 判断对象是否是括号中任意一个类型
print(isinstance([1,2,3],(list,tuple)))

'''
dir()  
'''
# 获取一个对象的所有属性和方法
print(dir('abc'))
print('abca'.count('a'))
print(len('abca'))

class MyObject:

    def __init__(self):
        self.x = 9
    def power(self):
        return self.x * self.x
    def __str__(self):
        return '你好我好大家好！'

obj = MyObject()
obj2 = MyObject()
print(hasattr(obj,'x'))  # 判断对象obj中是否包含一个属性叫x
print(hasattr(obj,'power'))
'''setattr()'''
# 如果属性存在赋新值
# 如果属性不存在则添加新属性并赋值
# 设置对象obj的属性x的值为10
setattr(obj,'x',10)
print(obj.power())

setattr(obj,'y',9)
print(hasattr(obj,'y'))

'''getattr()'''
print(getattr(obj,'y'))
print(getattr(obj,'x'))
print(getattr(obj2,'x'))
p = getattr(obj,'power')
print(p)
print(p())
#将对象的方法power内容修改为abs内容(求绝对值)
setattr(obj,'power',abs)   
p2 = getattr(obj,'power')  
print(p2(-5))

print(obj)
