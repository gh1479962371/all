'''
IO  Input/Output
'''
# 把文件从硬盘中读取到内存中是Input 输入
# 把文件从内存中输出到硬盘中是Output输出
'''
try:
    # 相对路径
    # f = open('test.txt','r')   # r:read
    # 绝对路径
    # 打开文件
    f = None
    f = open(r'E:\workspace\python\test2.txt','r')  
    # 读取文件
    r = f.read()
    print(r)
# except Exception e:
#     print('Exception='e)
# 关闭文件
finally:
    # print(f)
    if f:
        f.close()
'''

# python特有的读写方式
# encoding：指定编码方式
# read()：读取文件的全部内容
# readlines:读取文件的全部内容，然后按行封装为一个列表
# readline：
with open(r'E:\workspace\python\test.txt','r',encoding='utf-8') as f:
    # print(f.read())
    # l = f.read().split('\n')
    # l = f.readlines()
    l = f.readline()
    print(l)
    print(f.readline())   #读过一行后不会再读
    print(f.readline())
    
    print(l)
    print(l[0])
    print(l[1])

# w:write 覆盖写：如果文件存在，则覆盖原有内容；如果目标文件不存在，则创建新文件并写入内容
with open(r'E:\workspace\python\test.txt','w',encoding='utf-8') as f:
    f.write('国庆节快乐！')

# a:append 追加写
with open(r'E:\workspace\python\test.txt','a',encoding='utf-8') as f:
    f.write('国庆节快乐！')
