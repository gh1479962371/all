import requests
from lxml import etree
from time import sleep

# 获取章节列表页面代码
url = 'http://www.biquge.info/0_383/'
response = requests.get(url)
# 指定编码集
response.encoding = 'utf-8'
# print(response.text)
# 将文本格式页面转换为etree对象格式
selector = etree.HTML(response.text)
# 获取小说名称
title = selector.xpath('//div[@id="info"]/h1/text()')[0]

# 获取所有的章节地址
links = selector.xpath('//div[@id="list"]/dl/dd/a/@href')

# urls = []
# for link in links:
#     urls.append(url+link)
# 用列表生成式补全章节地址
links = [url+link for link in links]
# print(links)

# 下载章节
for link in links[:3]:
    sleep(2)   # 休息2秒，避免给对方服务器过大的压力
    response = requests.get(link)
    response.encoding = 'utf-8'
    selector = etree.HTML(response.text)
    with open('%s.txt'%title,mode='a',encoding='utf-8') as file:
        ctitle = selector.xpath('//h1/text()')[0]
        print('正在下载...%s'%ctitle)
        # 获取正文内容-方式一
        content = selector.xpath('//div[@id="content"]/text()')
        r = ''
        for line in content:
            r += line+'\n'

        # 获取正文内容-方式二
        # content = selector.xpath('string(//div[@id="content"])')
        # print(content)
        file.write(ctitle+'\n')
        file.write(r)

