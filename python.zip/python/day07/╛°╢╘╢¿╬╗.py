'''
绝对定位
'''
import sys 
from PyQt5.QtWidgets import QApplication,QWidget,QLabel

class Example(QWidget):

    def __init__(self):

        super().__init__()
        self.initUI()

    def initUI(self):
        lb1 = QLabel('邮政编码',self)
        lb1.move(10,10)
        lb2 = QLabel('手撕烤鸭',self)
        lb2.move(20,20)

        self.setGeometry(300,300,300,200,)
        self.setWindowTitle('绝对定位')
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    example = Example()
    sys.exit(app.exec_())

