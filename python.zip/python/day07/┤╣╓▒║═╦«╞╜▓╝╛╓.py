'''
框布局
'''

import sys 
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton,QHBoxLayout,QVBoxLayout

class Example(QWidget):

    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        # 创建2个按钮
        ok = QPushButton('OK')
        cancel = QPushButton('Cancel')

        # 创建一个水平布局
        hbox = QHBoxLayout()
        hbox.addStretch(1)   # 把按钮向右推动
        hbox.addWidget(ok)
        hbox.addWidget(cancel)

        # 创建一个垂直布局
        vbox = QVBoxLayout()
        vbox.addStretch(1)   # 向下推动按钮
        vbox.addLayout(hbox)


        # 在窗口中添加布局
        self.setLayout(vbox)
        self.setGeometry(300,300,150,150)
        self.setWindowTitle('绝对定位')
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    example = Example()
    sys.exit(app.exec_())


