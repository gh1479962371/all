import sys
from PyQt5.QtWidgets import QApplication,QWidget

# pyqt5应用必须创建一个应用程序对象
# sys.argv:
app = QApplication(sys.argv)

# QWidget是pyqt5所有用户界面对象的基类
window = QWidget()

# 调整窗口的初始大小
window.resize(250,150)

# 调整窗口出现的位置
window.move(300,300)

# 设定标题
window.setWindowTitle('Simple')

# 显示窗口
window.show()

# 干净退出
sys.exit(app.exec_())

