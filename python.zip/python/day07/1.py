# 输入一系列数字，判断是否是回文数据，例如[0,1,2,3,3,2,1,0]
s = input("请输入数字：").split(',')
print(type(s))
n = len(s)
if n%2 == 0:
    for i in range(n//2):
        if s[i] == s[-(i+1)]:
            continue
        else:
            print('false')
            break
    else:
        print('true')
else:
    print('false')

# filter()函数的用法
l = [2,3,23,3,9,8,78,56,0,4,7]
filter(lambda x: a%2==0 ,l)
print(filter)




