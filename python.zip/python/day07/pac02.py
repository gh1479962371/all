import requests
from lxml import etree
from time import sleep

# 获取小说名称和所有章节地址
def download_chapter_list(url):
    # 获取章节列表页面
    # url = 'http://www.biquge.info/0_383/'
    response = requests.get(url)
    # 指定编码集
    response.encoding = 'utf-8'
    # print(response.text)
    # 将文本格式页面转换为etree对象格式
    selector = etree.HTML(response.text)
    # 获取小说名称
    title = selector.xpath('//div[@id="info"]/h1/text()')[0]

    # 获取所有的章节地址
    links = selector.xpath('//div[@id="list"]/dl/dd/a/@href')

    # urls = []
    # for link in links:
    #     urls.append(url+link)
    # 用列表生成式补全章节地址
    links = [url+link for link in links]
    return title,links

# 获取某一章节标题和章节正文内容
def download_chapter_content(link):
    try:
    # 下载章节
        sleep(2) # 休息2秒，避免给对方服务器过大的压力
        response = requests.get(link)
        response.encoding = 'utf-8'
        selector = etree.HTML(response.text)
        ctitle = selector.xpath('//h1/text()')[0]
        print('正在下载...%s'%ctitle)
        # 获取正文内容-方式一
        content = selector.xpath('//div[@id="content"]/text()')
        result = ''
        for line in content:
            result += line+'\n'
        return ctitle,result
        # 获取正文内容-方式二
        # content = selector.xpath('string(//div[@id="content"])')
        # print(content)
    except Exception as e:
        print(e)
        download_chapter_content(link)

# 下载/保存某一章节标题和章节正文内容-->以小说名称为文件名的文件里
def save_content(title,ctitle,result):
    with open('%s.txt'%title,mode='a',encoding='utf-8') as file:
        file.write(ctitle+'\n')
        file.write(result)

# 主函数：通过循环遍历每一章节的地址为基础调用‘获取章节标题、内容函数’和‘章节标题、内容写入文件函数’，
# 主函数：通过遍历将所需要的章节标题和内容全部写入‘以小说名为文件名’的文件里
def main(url):
    # 获取小说标题和所有章节的地址
    title, links = download_chapter_list(url)
    # 开始下载
    for link in links[:3]:
        ctitle,result = download_chapter_content(link)
        save_content(title,ctitle,result)

# 调用主函数，完成将章节写入文件
if __name__ == "__main__":
    main('http://www.biquge.info/0_383/')