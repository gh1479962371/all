'''
pyqt5 
'''
import sys
from PyQt5.QtWidgets import QWidget,QApplication

app = QApplication(sys.argv)
widget = QWidget()
widget.show()
widget.setWindowTitle("Hello PyQt5")
sys.exit(app.exec_())

