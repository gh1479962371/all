import sys 
from PyQt5.QtWidgets import QApplication,QWidget
from PyQt5.QtGui import QIcon

class Example(QWidget):
     
    # 构造方法
    def __init__(self):
        # 调用父类QWidget的构造方法
        super().__init__()
        self.initUI()

    
    # 绘制界面
    def initUI(self):
        # 设置窗口的位置和大小
        self.setGeometry(300,300,300,200)
        self.setWindowTitle('图标')
        # 设置窗口的图标
        self.setWindowIcon(QIcon('day07\h3.png'))
        # 显示窗口
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    example = Example()
    sys.exit(app.exec_())
