'''
迭代
'''

names = ('徐美斌','白宝蕾','陈杏梅','党海斌','冯凯')
#
# 遍历——迭代 Iteration
for name in names:   # names:可迭代对象
    print(name)

index = 0
for name in names:
    
    print(index+1,end=' ')
    print(name)
    index += 1

for i,name in enumerate(names):    # enumerate:枚举
    print(i+1,name)


# for(int i=0;i<names.length;i++){
#     system.out.print(names[i])
# }

print('---------------------------------------')

s = 'abcdef'
for c in s:
    print(c)

# 字典的3种迭代方式
d = {'a1':1,'b1':2,'c1':3}
# 迭代key
for k in d:
    print(k,d.get(k))

# 迭代values
for v in d.values():
    print(v)

# 迭代key:vaule
for k,v in d.items():
    print(k,v) 


