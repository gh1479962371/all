'''
python高级特性

切片
列表的切片结果还是列表
元组的切片结果还是元组
字符串的切片结果还是切片
'''

names = ('徐美斌','白宝蕾','陈杏梅','党海斌','冯凯')

pre = [names[0],names[1],names[2]]
print(pre)
print(names[:2])
print(names[0:3])   # 取0,1,2的数
print(names[3:])   # 取4,5 的数
print(names[-2:])   # 后面不写，到结束为止
print(names[-7:])

n = list(range(100))
print(n)            #0-100之间的数，不包括100
print(n[:])         #0-100之间的数，不包括100
print(n[:10])       #0-10之间的数
print(n[:10:2])     #10以内的偶数
print(n[1:10:2])    #10以内的奇数
print(n[::5])       #隔五取一

'''
元组也适用于切片，但是结果还是元组
'''

