'''
列表生成式
'''

l1 = [1,2,3,4,5,6,7,8,9,10]
l2 = list(range(1,11))
print(l2)

# [1*1,2*2,...,10*10]
# 方式一
l3 = []
for i in range(1,11):
    l3.append(i*i)
print(l3)
# 方式二
l4 = [i*i for i in range(1,11)]
print(l4)

# 练习[4,16,36,64,100]
l5 = [i*i for i in range(1,11) if i%2==0]
print(l5)
l5 = [i*i for i in range(2,11,2)]
print(l5)

l6 = [x+y for x in 'ABC' for y in 'xyz']
# for x in 'ABC':
    # for y in 'xyz':
    #     x+y
print(l6)