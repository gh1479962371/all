# 2.用递归函数实现fibonaci数列,算出第几项
# 1,1,2,3,5,8,13,21
def fb(n):
    if n==1 or n==2:
        return 1
    return fb(n-2)+fb(n-1)
print(fb(7))

# 4.实现一个trim()函数，利用切片取出字符串前后的空格
s =  '    gaohuan  '
def trim(s):
    if s[0]==' ':
        return (trim(s[1:]))
    elif s[-1] == ' ':
        return (trim(s[:-1]))
    else:
        return s
print(s)
print(trim(s))

# 3.用递归实现汉诺塔游戏 (不超过10个盘子)
# 输出结果：
# A -> B 
# A -> C
# # B -> C
def move(n, a, b, c):
    if(n == 1):
        print(a,"->",c)
    else:
        # 先把上面的n-1个盘子从a移动到b柱子上
        move(n-1, a, c, b)
        # 然后把最底下的盘子从a移动到c柱子上
        move(1, a, b, c)
        # 最后把b柱子上的n-1个盘子移动到c柱子上
        move(n-1, b, a, c)
move(3, "A", "B", "C")

# 5.随机生成一个5位的验证码，包含A-Za-z0-9
import random
# r1 = list(range(ord('A'),ord('Z')+1))
# r2 = list(range(ord('a'),ord('z')+1))
# r3 = list(range(ord('0'),ord('9')+1))
# r1.extend(r2)
# r1.extend(r3)
# for i in range(5):
#     print(chr(random.choice(r1)),end="")

def f():
    s = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789'
    verify = ''
    for i in range(5):
        rand = random.randint(0,61)
        verify += s[rand]
    return verify
print(f())


# 6.将下面列表中的所有字符变为小写：(列表生成式)
# ['Tom','MIKE','VM','Python']
s = ['Tom','MIKE','VM','python']
# print([s[i].lower() for i in range(4)])
for i in range(4):
    s[i] = s[i].lower()
print(s)

a = 'frFGGGBhY'
print(a.lower())
print(a)
