'''
递归函数
'''

# n! = 1 * 2 * 3 * 4 * ... (n-1) * n
# 方案一：用循环
def fact1(n):
    s = 1
    for i in range(1,n+1):
        s = s * i
    return s
print(fact1(5))

'''
n!=(n-1)! * n
(n-1)!=(n-2)! * n-1
...
'''
# 方案二：用递归
# 1.自己调用自己的函数
# 2.一定要有边界条件（结束条件）
# 尾递归不受递归深度的限制
def fact2(n):
    if n==1:
        return 1
    return fact2(n-1)*n     # 递归调用
print(fact2(5))
'''
fact2(5)
fact2(4)*5
fact2(3)*4*5
fact2(2)*3*4*5
fact2(1)*2*3*4*5
1*2*3*4*5
'''
1,1,2,3,5,8,13,21
def fb(n):
    if n==1 or n==2:
        return 1
    return fb(n-2)+fb(n-1)
print(fb(7))