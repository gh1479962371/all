'''计算平方'''
# def power(x):
#     return x * x
# print(power(3))

'''计算n次方'''
# def power(x,n):
#     s = 1
#     for i in range(n):
#         s *=x
#     return s
# print(power(3,3))
# print(power(3,2))
'''默认参数：有默认值的参数，调用时可以传参，也可以不传参
注意：
1.默认参数必须在位置参数后面
2.变化小的参数可以作为默认参数
'''
# def power(x,n=2):
#     s = 1
#     for i in range(n):
#         s *=x
#     return s
# print(power(3)) 

# def person(name,gender,age,city):      
#     print(name,gender,age,city)
# person('赵旭超','男',22,'延安')

# def person(name,age,gender='男',city='西安'):
#     print(name,age,gender,city)
# person('tom',22)
# person('jerry',23,city='咸阳')
# person('marry',23,city='咸阳',gender='女')
# # person(city='武汉',gender='男','lucy',21)      #  城市不能写前面，位置参数跟随关键字参数

# 问题：3，5，34，22，99，1，6 求和
# def s(digits):
#     ss = 0
#     for i in digits:
#         ss +=i
#     return ss
# digits = [3,5,34,22,99,1,6]
# print(s(digits))
# print(s([3,5,34,22,99,1,6]))
'''可变参数,参数个数不受限'''    #特殊情况下使用
def s(*digits):         # 变成元组，加*封装成元组
    ss = 0
    for i in digits:
        ss +=i
    return ss
print(s(3,5,34,22,99,1,6))

digits = [3,5,34,22,99,1,6]
print(s(digits[0],digits[1],digits[2],digits[3],digits[4],digits[5],digits[6]))
print(s(*digits))

'''关键字参数'''
# def student(name,age):
#     print(name,age)

# student('周思涵',22)              # 此处无需再次打印

# def student(name,age,*arg):       # 可变参数在此处意义不大  *封装成元组
#     print(name,age,arg)

# student('周思涵',22,'商洛',150)

'''关键字参数：
1.参数个数不受限
2.参数必须以key=value的形式出现
'''
# def student(name,age,**arg):        # ** 封装成字典
#     print(name,age,arg)

# student('周思涵',22,gender='商洛',weight=150)

'''
命名关键字参数
1.命名关键字参数和位置参数中间要用*隔开，但是如果有可变参数，则可以不单独写*
'''
# def somebody(name,age,**kw):        # kw = key word   特殊情况下的特殊用法
#     print(name,age,kw)

# somebody('张三',20,gender='男',city='渭南',hobby='吃面')

# def somebody(name,age,*,gender,city):        # kw = key word * 没有什么实际意义，去掉也可以
#     print(name,age,gender,city)

# somebody('张三',20,gender='男',city='渭南')

# def somebody(name,age,*arg,gender,city):       # 如果有可变参数，则可不单独写*
#     print(name,age,arg,gender,city)

# somebody('张三',20,2,3,gender='男',city='渭南')

'''
参数组合
如果有多种参数类型，注意传参顺序
'''
# def f(a,b,c=1,*arg,**kw):
#     print(a,b,c,arg,kw)

# f(3,5,2,9,6,name = 'tom')               # 3 5 2 (9, 6) {'name': 'tom'}

# def f(a,b,c=1,*arg,**kw):
#     print(a,b,c,arg,kw)
# f(3,[5,3,4,7,8],2,9,6,name = 'tom') 

# def f2(*arg,**kw):
#     print(arg,kw)

# f2(3,5,2,9,6,name = 'tom') 

# def f(a,b,c=1,*arg,**kw):
#     print(a,b,c,arg,kw)
# # f(3,5,2,9,6,name = 'tom') 
# arg1 = (3,5,2,9,6)
# arg2 = {"name" : 'tom',"age":20}
# f(arg1,arg2)
# f(*arg1,**arg2)

# def f2(a,b,c=1,*arg,**kw):
#     print(arg,kw,a,b)

# f2(3,5,2,9,6,name = 'tom') 
