import requests
from lxml import etree
from time import sleep

def download_chapter_list(url):
    # 获取章节列表页面
    # url = 'http://www.biquge.info/0_383/'
    response = requests.get(url)
    # 指定编码集
    response.encoding = 'utf-8'
    # print(response.text)
    # 将文本格式页面转换为etree对象格式
    selector = etree.HTML(response.text)
    # 获取小说名称
    title = selector.xpath('//div[@id="info"]/h1/text()')[0]

    # 获取所有的章节地址
    links = selector.xpath('//div[@id="list"]/dl/dd/a/@href')

    # urls = []
    # for link in links:
    #     urls.append(url+link)
    # 用列表生成式补全章节地址
    links = [url+link for link in links]
    return title,links

def download_chapter_content(link):
    try:
    # 下载章节
        sleep(2) # 休息2秒，避免给对方服务器过大的压力
        response = requests.get(link)
        response.encoding = 'utf-8'
        selector = etree.HTML(response.text)
        ctitle = selector.xpath('//h1/text()')[0]
        print('正在下载...%s'%ctitle)
        # 获取正文内容-方式一
        content = selector.xpath('//div[@id="content"]/text()')
        result = ''
        for line in content:
            result += line+'\n'

        # 获取正文内容-方式二
        # content = selector.xpath('string(//div[@id="content"])')
        # print(content)
    except Exception as e:
        print(e)
        ctitle,result = download_chapter_content(link)
    finally:
        return ctitle,result

def save_content(title,ctitle,result):
    with open('%s.txt'%title,mode='a',encoding='utf-8') as file:
        file.write(ctitle+'\n')
        file.write(result)
        
def main(url):
    # 获取小说标题和所有章节的地址
    title, links = download_chapter_list(url)
    # 开始下载
    for link in links[:3]:
        ctitle,result = download_chapter_content(link)
        save_content(title,ctitle,result)

def biquge(url):
    pages = [url+'/%s.html'%i for i in range(1,4)]
    
    for page in pages:
        response = requests.get(page)
        selector = etree.HTML(response.text)
        novels = selector.xpath('//*[@id="main"]/div[1]/ul/li/span[2]/a/@href')
        for novel in novels[1:4]:
            # print(novel)
            main(novel)

if __name__ == "__main__":
    # main('http://www.biquge.info/0_383/')
    biquge('http://www.biquge.info/paihangbang_allvisit')
