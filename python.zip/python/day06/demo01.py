import requests
from lxml import etree

page = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        .item-0 {
            color: red;
        }
        .item-1 {
            color:green;
        }
    </style>
</head>
<body>
    <ul>
            <li class="item-0"><a href="link1.html">first item</a></li>
            <li class="item-1"><a href="link2.html">second item</a></li>
            <li class="item-inactive"><a href="link3.html">third item</a></li>
            <li class="item-1"><a href="link4.html">fouth item</a></li>
            <li class="item-0"><a href="link5.html">fifth item</a></li>
            <li class="item-0">else item</li>
    </ul>
</body>
</html>
'''

selector = etree.HTML(page)
print(selector)
# xpath   [1]：从1开始
# li = selector.xpath('//html/body/ul/li')
# a[0]、text[0]表示去掉列表显示的形式
a = selector.xpath('//html/body/ul/li[1]/a')
print(type(a))   # a是列表形式
print(a[0].text)
text = selector.xpath('//html/body/ul/li[2]/a/text()')[0]
print(text)

li3 = selector.xpath('//li[@class="item-inactive"]/a')[0]
print(li3.text)

a = selector.xpath('//*[@href="link5.html"]')[0]
print(a.text)
print(a.xpath('text()'))
href = selector.xpath('//li[@class="item-inactive"]/a/@href')[0]
print(href)

li6 = selector.xpath('//li[6]/text()')[0]
print(li6)
