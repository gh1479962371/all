# price =int(input('请输入单价（￥）:'))
# amount =int(input('请输入数量:'))
# money =int(input('请输入金额（￥）:'))
# print('应收金额为:￥%.1f，找零为：￥%.1f'%(price*amount,money-price*amount))

a =input('请输入单价（￥）:')