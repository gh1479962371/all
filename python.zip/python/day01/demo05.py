'''
列表 list 
'''

# 定义列表 列表中每一个数据就是一个元素
# 列表是一个有序的集合,原则上可变
# 下标(index) 0      1       2        3       4
names = ['徐美斌', '白宝蕾', '陈杏梅', '党海斌', '冯凯']
# 输出列表
print(names)

# 获取列表长度 len
length = len(names)
print('length=%d' % length)

# 按照下标(索引)获取列表元素
print(names[0])
# print(names[5])  #list index out of range
print(names[-1])  # 获取列表最后一个元素
print(names[-2])  # 获取列表倒数第二个元素
print(names[-5])  # 获取列表第一个元素

# 添加元素
a = names.append('高换')  # append:追加到列表的末尾
print('----------')
print(a)
print(names)
names.insert(1, '郭金凤')
print(names)
namess = ['今天', '明天', '后天', '大后天']
names.extend(namess)
print(names)
names.reverse()
print(names)
# 删除元素
classmate1 = names.pop()  # pop删除最后一个元素，并返回删除的元素
print(names)
print(classmate1)
classmate2 = names.pop(2)  # pop(n)删除指定下标的元素,并返回指定下标的元素
print(classmate2)
print(names)
names.remove('高换')
print(names)
# 替换/修改
names[0] = '陆凯利'
print(names)

names.append(181122)  # 可追加任意类型的元素
print(names)
names.append([1, 2, 4])  # 可以进行列表套列表
print(names)
print(names[-1][0])
#  空列表
a = []
print(a)
