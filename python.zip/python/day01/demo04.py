'''
字符串与编码
'''

# 乱码
# 'a' -> 97
# 'A' -> 65

# GB2312 gbk
# unicode 2个字节表示一个文字
# utf-8 1-3个字节

# ord():获取字符的整数编码
print(ord('2'))
print(ord('a'))
print(ord('换'))
print(ord('.'))
print(ord('\\'))
print(ord('\n'))
print(ord('n'))
# chr():获取数字编码对应的字符
print(chr(97))
print(chr(250))
print(chr(250))
print('------')
print(chr(53))

# hex():转换成十六进制
print(hex(ord('女')))
# \u: 表示将十六进制编码转换为字符串
print('\u5973')

# 进制转换
# 二进制、八进制、十六进制、十进制
a = 10
# bin():将十进制转换成2进制  0b***
print(bin(a))
# oct():将十进制转换成八进制 0o***
print(oct(a))
# hex():将十进制转换成十六进制 0x***
print(hex(a))
# int():将二进制、八进制、十六进制转换成十进制 10
print(int(0xa))

# 字符串的长度 len()
name = 'tommy'
print(len(name))
print(len('张三丰'))

# 字符串的格式化
name = input('请输入姓名：')
age = int(input('请输入年龄：'))  # '25'->25 #控制台输入的都是字符
# 我叫张三，今年30岁，我来相亲了。
# %：表示占位符
# %s:字符串  %d:整数  %x:16进制数 %f:浮点数
print('我叫%s，今年%d岁，我来相亲了。' % (name, age))
# %s带任何情况下都可以h
print('我叫%s，今年%s岁，我来相亲了。' % (name, age))
# 我今年减肥了10%。
percent = int(input('减肥百分比：'))
print('我今年减肥了%d%%' % percent)

# format()
print('我叫{0}，今年{1}岁，我来相亲了。我今年减肥了{2:.2f}%'.format(name, age, percent))
