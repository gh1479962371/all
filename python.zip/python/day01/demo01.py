'''
输入与输出
日期：2020-09-24
'''
# 输出语句
#字符串要用单引号或双引号括起来
print("Life is short, so we use Python")
print('人生苦短，我用Python')             
#可以输出多个字符串，中间用逗号隔开
print('hi','tom')
print('hi''tom')
print(300+200)
print('100+400=',100+400)

# 输入
age = input('请输入您的年龄：')
print('age=',age)

print('hi'+'tom')
print('hi','tom')
print('hi''tom')
print('hi' 'tom')