'''
数据类型
'''


'''整数'''
#整数 1,5，100，-200
# 以0x开始代表十六进制的整数

'''浮点数 3.14 4.414 1.732 0.618'''
# 科学计数法：1.234e5  表示1.234的5次方

''' 字符串 
'hi' 'welcome to XiAn'I'm fine"
'''
# \ 代表转义字符 后面的'要输出来
print('I\'m \'fine\'')
print("I\'m ok")
# \\代表后面的\可以输出来
print('\\')
# \n换行 \t制表符(对齐)
print('您\n好！')
print('您\t好')
print('''全诗分为两节，恰似并置在
两组镜头。''')
print(r'\\t\\') # r代表后面的内容是正常的regular
print(r'\n\thhhh')

# 打印多行
print('''你好
张三
该还钱了！''')


'''布尔值boolean'''
#True False 区分字母的大小写
print(True)
print(False)
print(5<3)

# 布尔值之间可以进行逻辑运算
#and or not 
print(1==4 or 1<6)  #逻辑与 双目运算符
print(not 2>1)      #逻辑非 单目运算符


'''空值'''
# None
print(None)


'''变量'''
# 变量名必须是：大小写英文字母，数或者下划线_
a = 100
a1 = 200
a_2 = 300
#2b = 400 #非法，不能以数字开头
_a = 20
# 见名知意
a = 22
age = 22
name = 'xiaowang'
# 驼峰命名法
teacherFirstName = 'wangyu'
# 下划线命名法
teacher_first_name = 'wangyu'
a = 22 
a = 'mike'  
# int a = 22    java里的写法
# = 代表赋值符号
# == 代表真正意义上的等号

'''常量'''
# 常量-名字中的全部字母大写
PI = 3.1415926  #假常量
PI = 3.22
