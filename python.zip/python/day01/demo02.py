# 缩进indent
# 大小写敏感
age = 22
if age>18:   #判断条件
    print('成年人')
    print('成年人')
    print('成年人')
else:
    print('未成年人')
    