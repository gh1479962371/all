'''
面向对象编程
oop object Oriented Programming
'''

# 什么是对象？
# 什么是类？

dir1 = {'徐美斌': 80, '白宝蕾': 90, '陈杏梅': 95, '党海斌': 98, '冯凯': 99}
s1 = {'name': '徐美斌', 'age': 20, 'score': 80}
s2 = {'name': '白宝蕾', 'age': 22, 'score': 90}


# 函数
def print_score(stu):
    print('%s:%d' % (stu['name'], stu['score']))


print_score(s1)


# 定义一个类:使用关键字class
# 类名：首字母大写（约定俗称）
class Student:

    # 方法 method （类中的函数叫方法）
    # __init__():构造方法Constructor
    # 类中的方法必须有一个叫self的参数，并且是第一个参数
    # 并且调用方法时，不要给self传值，系统会自动给self传值
    # self指当前对象
    def __init__(self, name, age, score):
        # 属性：用于描述对象
        # 成员变量 ：作用范围在整个类中
        self.name = name
        self.age = age
        self.score = score
        # 局部变量：只在当前方法中有用
        # gender = 'F'

    def print_score(self):
        print('%s:%d' % (self.name, self.score))


# 创建对象
# 把类具体化的过程叫做实例化 instantiation
# # 实例(Instance)
s3 = Student('陈杏梅', 20, 95)  # 调用Student类的构造方法：__init__
# 调用对象的方法
s3.print_score()

s4 = Student('党海斌', 24, 28)
s4.print_score()
# 给对象添加新属性
s4.hobby = '吃面'
print('------------------------------------------')
print(s4.hobby)
print(dir(s4))  # dir:查s4的所有属性和方法
# 修改对象属性的值
s4.score = 98
print(s4.score)
s4.print_score()

'''
封装
'''


class Student:

    def __init__(self, name, age, score):

        # 访问限制
        # 在成员变量的前面加两个_，变量就变成了私有变量
        # private类型的变量只能内部访问 ，不能在外部访问
        self.__name = name  # _Student__name
        self.__age = age
        self.__score = score

    def print_score(self):
        print('%s:%d:%d' % (self.__name, self.__age, self.__score))

    def grade(self):
        if self.__score >= 90:
            print('优秀')
        elif self.__score >= 60:
            print('合格')
        else:
            print('不及格')

    def print_age(self):
        print('%s:%d' % (self.__name, self.__age))

    # getter/setter
    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def get_score(self):
        return self.__score

    def set_score(self, score):
        if score >= 0 and score <= 100:
            self.__score = score
        else:
            print('输入错误，成绩应该在0-100之间！')

    def get_age(self):
        return self.__age

    def set_age(self, age):
        if age > 0 and age <= 150:
            self.__age = age
        else:
            print('输入错误，年龄应该在1-150岁之间！')


# 普通函数
def print_score(name, score):
    print('%s:%d' % (name, score))


s1 = Student('冯凯', 25, 99)
print('-----------------------------------------------------------------!!')
# print_score(s1.__name,s1.__score)  #外部不能访问(系统会报错，实际上系统已经把的__name自动改成_Student__name)
print_score(s1.gttetname(), s1.get_score())
print_score(s1._Student__name, s1._Student__score)
print(s1._Student__name)

s1.print_score()
s1.grade()

s1.__score = -1  # 增加了一个属性__score,因为类中并没有__score的属性了（虽然类中写的是这样的），因为系统私有后自动改为_Student__score
print('--------------------------------------------------------')
s1.print_score()
print(s1.__score)
print(s1._Student__score)

s1.__age = 0
s1.print_age()
print(s1.__age)
print(s1._Student__age)

n1 = Student('高换', 26, -10)
print(n1._Student__age)

n1.set_age(25)
print(n1.get_age())
