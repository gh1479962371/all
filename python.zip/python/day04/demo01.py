'''
高阶函数
'''


print(abs(-4)) # 调用函数
# 函数名就是一个指向函数的变量
print(abs)     # 只写函数名时，代表这个函数本身<built-in function abs>

# 函数本身也是一个数据，可以进行赋值
f = abs
print(f)
print(f(-3))

# abs = 3
# print(abs)
# print(abs(-5))   

'''
函数作为参数
'''
import math
def add(x,y,f):
    return f(x)+f(y)
print(add(-3,5,abs))
print(add(4,16,math.sqrt))
print(add(-3,5,math.sin))

# map()：映射
def f(x):
    return x*x*x
# g(2)
l = [1,2,3,4,5,6,7,8,9]

r = map(f,l)
print(r)
print(list(r))

'''
函数作为返回值
'''
def sum1(*args):
    s= 0
    for i in args:
        s += i
    return s
print('-------------------')
print(math.sqrt(16))
print(sum1(1,2,3,4))

def sum2(*args):
    def sum():
        s = 0
        for i in args:
            s += i
        return s
    return sum
f = sum2(1,2,3,4)
print('------------------------------------------')
print(f)
print(sum2(1,2,3,4))
print(f())

# 闭包 closure

# 计数器
# count = 0
# count += 1
# count = 5
# count += 1
# 利用闭包实现安全计数器
# 闭包：当一个函数a返回了另一个函数b，a内部的变量被b函数引用，就成为闭包

def createCounter():
    count = [0]   # 不能写成：count = 0
    def counter():
        count[0] += 1
        return count[0]
    return counter
t = createCounter()
print(t())
print(t())
print(t())
print(t())
'''
匿名函数
'''
def f3(x):
    return x*x
print(f3)
# lambda表达式(相当于函数的另一种写法：只需要写参数和函数体即可)
f4 = lambda x: x*x
print(f4)
l = [1,2,3,4,5,6,7,8,9]
r = map(lambda x: x*x,l)
print(list(r))
r = map(lambda  x: x*10,l)
print(list(r))




