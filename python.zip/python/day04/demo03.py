'''
继承与多态
'''
# object类是所有类的父类
class Animal(object):    # 默认继承object类，可以不写

    def run(self):
        print('Animal is running...')

# 继承：Dog类继承了Animal类
# Animal:父类
# Dog:子类
class Dog(Animal):
    
    # 子类在继承父类的同时，也可以有自己的方法
    def eat(self):
        print('狗狗在吃肉...')
    
    # 多态
    # 子类的run方法覆盖了父类的run方法 override
    def run(self):
        print('Dog is running...')

class Cat(Animal):

    def run(self):
        print('Cat is running...')

a = Animal()
a.run()
d = Dog()
d.run()
d.eat()
c = Cat()
c.run()

'''类就是类型,我们写的类就是一个自定义类型'''
# 判断对象的类型（返回True 或者 Flase)
r = isinstance(d,Dog)  # 判断变量d是否是Dog类型（判断d是否是Dog的实例）
print(r)
r = isinstance(2,int)
print(r)
r = isinstance(2,float)
print(r)
print(isinstance(1,float))
# 多态（一个对象表现出多种类型）
# 在继承关系中，如果一个实例的类型是某个子类，n那么这个实例的类型也可以被看做父类类型（父++）
print(isinstance(d,Animal)) # d是Dog的实例，Dog继承了Animal
print(isinstance(a,Dog))
print(isinstance(d,Cat))
# 多态的具体应用
def run_twice(animal):
    animal.run()

run_twice(a)
run_twice(d)
run_twice(c)

