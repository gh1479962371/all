# -*- coding:utf-8 -*-

from logger import LOG
from threading import Thread
from Queue  import Queue

class TaskObject:
    """ this is task object, taskfun is function , taskparam is the parameters of taskfun"""

    def __init__(self, taskfun, taskparam):
        self.taskfunction = taskfun
        self.taskparameter = taskparam

    def run(self):
        self.taskfunction(**self.taskparameter)


def errorAndExit():
    print -1
    exit(-1)


def thread_run(taskqueue):
    while True:
        task = taskqueue.get()
        task.run()
        taskqueue.task_done()


def createThreadPool(poolsize,taskqueue):
    LOG.info("init threadpool,poolsize："+str(poolsize))
    for i in range(poolsize):
        t = Thread(target=thread_run,args=(taskqueue,))
        t.setDaemon(True)
        t.start()


def executeTaskQueue(tasklist,poolsize):
    taskqueue = Queue()
    for taskobject in tasklist:
        taskqueue.put(taskobject)
    createThreadPool(poolsize,taskqueue)
    taskqueue.join()
