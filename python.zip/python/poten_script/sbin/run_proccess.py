# -*- coding:utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')
from sys import argv
from logger import LOG
import commonfun
import datetime
import os
import commands
import codecs
from access_channel_conf import ACCESS_CHANNELS,PARALLELS,STATUSFILENAME

try:
    script,batchdate_str = argv
except Exception as e:
    LOG.error(e.message)
    commonfun.errorAndExit()

#* 解析传入的日期
try:
    batchdate = datetime.datetime.strptime(batchdate_str, "%Y%m%d")
except Exception as e:
    LOG.error(e.message)
    commonfun.errorAndExit()


SCRIPT_DIR = os.path.dirname(__file__)
PROJECT_DIR = SCRIPT_DIR.rstrip('sbin')
LOG_DIR = PROJECT_DIR+"log"


tasklist = list()
IS_SUCCESS = 0
successlist = list()


def channel_preprocess(**kwargs):
    global IS_SUCCESS
    datadate_str = kwargs.get("batchdate")
    channelsql = kwargs.get("channelsql")
    channelsql_path = PROJECT_DIR+"sql/"+channelsql
    # command = "beeline --hivevar BATCH_DAY=%s  -f %s 2>&1 " %(datadate_str,channelsql_path)
    # status,stdout = commands.getstatusoutput(command)
    status,stdout = (0,"success")
    if status != 0:
        IS_SUCCESS = 1
        LOG.error("task error,message:"+stdout)
    else:
        successlist.append(channelsql)


def getSuccessChannel():
    status_fullpath = LOG_DIR +"/" + STATUSFILENAME+batchdate.strftime("%Y%m%d")
    successsqls = list()
    successfile = open(status_fullpath, "a+")
    for line in successfile.readlines():
        data = line.strip('\n')
        if len(data) != 0:
            successsqls.append(data)
    successfile.close()
    return successsqls

def saveStatus():
    status_fullpath = LOG_DIR + "/" + STATUSFILENAME + batchdate.strftime("%Y%m%d")
    successfile = open(status_fullpath, "a")
    for sql in successlist:
        successfile.write(sql)
        successfile.write("\n")
    successfile.close()

for item in ACCESS_CHANNELS:
    channelsql = item[0]
    channeldelta = item[1]
    successsqls = getSuccessChannel()
    if channelsql in successsqls:
        continue
    channeldate = (batchdate - datetime.timedelta(channeldelta)).strftime("%Y%m%d")
    tasklist.append(commonfun.TaskObject(channel_preprocess,{"channelsql":channelsql,"batchdate":channeldate}))


commonfun.executeTaskQueue(tasklist,PARALLELS)
saveStatus()





