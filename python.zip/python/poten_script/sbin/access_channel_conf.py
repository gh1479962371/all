# -*- coding:utf-8 -*-


ACCESS_CHANNELS = [
    ("init.sql",1),
    ("init2.sql",1)
]


PARALLELS = 4

STATUSFILENAME="taskstatus"

