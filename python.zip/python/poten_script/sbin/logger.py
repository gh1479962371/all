# -*- coding:utf-8 -*-

import logging
from logging.handlers import TimedRotatingFileHandler

LOG_BASE_PATH = "E:\\PycharmProjects\\cgbchina\\log\\"
LOG_FILENAME = "poten.log"
LOG_NAME = "poten"
LOG = logging.getLogger(LOG_NAME)

# logging.basicConfig(level=logging.INFO)            #*开启后输出到终端中

formatter = logging.Formatter("%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s")
handler = TimedRotatingFileHandler(LOG_BASE_PATH+LOG_FILENAME,when="midnight",interval=1,encoding="UTF-8")
handler.suffix = "%Y%m%d.log"
handler.setFormatter(formatter)
LOG.addHandler(handler)
LOG.setLevel(logging.INFO)
