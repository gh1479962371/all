'''
菜单栏
'''

import sys
from PyQt5.QtWidgets import QMainWindow,QApplication,qApp,QAction
from PyQt5.QtGui import QIcon


class Example(QMainWindow):

    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        # 创建一个事件，包含特定的图标和标签
        exitAction = QAction(QIcon('exit.png'),'&退出',self)
        # 定义该操作的快捷键
        exitAction.setShortcut('Ctrl+Q')
        # 创建一个提示
        exitAction.setStatusTip('退出程序')
        # 绑定操作
        exitAction.triggered.connect(qApp.quit)

        testAction = QAction(QIcon('day08/exit.png'),'&测试',self)
        # 定义该操作的快捷键
        testAction.setShortcut('Ctrl+F')
        # 创建一个提示
        testAction.setStatusTip('测试程序')
        # 绑定操作
        testAction.triggered.connect(qApp.quit)
        

        # 创建一个菜单栏
        menu = self.menuBar()
        # 添加菜单
        fileMenu = menu.addMenu('&File')
        editMenu = menu.addMenu('&Edit')
        # 添加菜单项
        fileMenu.addAction(testAction)
        fileMenu.addAction(exitAction)
        editMenu.addAction(exitAction)
        #
        # 创建工具栏
        toolBar = self.addToolBar('Exit')
        # 添加事件
        toolBar.addAction(exitAction)

        # 创建状态栏
        self.statusBar()
        self.setGeometry(300,300,250,150)
        self.setWindowTitle('菜单演示')
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    example = Example()
    sys.exit(app.exec_())

