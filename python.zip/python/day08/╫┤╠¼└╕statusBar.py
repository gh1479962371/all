'''
状态栏
'''

import sys
from PyQt5.QtWidgets import QApplication,QMainWindow

class Example(QMainWindow):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # 创建状态栏
        bar = self.statusBar()
        # 显示信息
        bar.showMessage('Python 3.8.5 64-bit')
        bar.showMessage('Java 5.0')

        self.setGeometry(300,300,250,150)
        self.setWindowTitle('状态栏')
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    example = Example()
    sys.exit(app.exec_())
