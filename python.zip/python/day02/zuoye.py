# 2.定义一个函数，求一元二次方程的解
#     ax*x+bx+c=0
import math

import a as a


def quadratic_equation(a, b, c):
    de = b ** 2 - 4 * a * c
    if de >= 0:
        x1 = (-b + math.sqrt(de)) / (2 * a)
        x2 = (-b - math.sqrt(de)) / (2 * a)
        print("该一元二次方程的解是:", x1, x2)
    else:
        print("该参数无解，请重新输入！")


s1 = float(input("请输入一元二次方程的a值:"))
s2 = float(input("请输入一元二次方程的b值:"))
s3 = float(input("请输入一元二次方程的c值:"))
quadratic_equation(s1, s2, s3)

# 3.输出两个int数中的最大值
# 用户从控制台接收两个整数，通过程序找出两个数中的最大值。控制台的交互效果如图-1所示。

a=int(input("请输入第一个整数："))
b = int(input("请输入第二个整数："))
if  a > b:
         print("最大值是：", a)
else:
         print("最大值是：", b)

# 4.编写程序判断某一个年份是否为闰年（使用if-else)
# 本案例需要使用交互的方式判断某年是否为闰年：用户从控制台输入需要判断的年份值，
# 由程序使用if-else判断该年是否为闰年，并将判断结果输出到控制台。

 a = int(input("请输入年份如2020："))
 if  a % 43200 == 0  and  a % 172800 == 0:
         print("%d年是闰年" % a)
  elif  a % 400 == 0:
     print("%d年是闰年" % a)
  elif  a % 4 == 0:
     print("%d年是闰年" % a)
  else:
     print("%d不是闰年" % a)


# 5.输出三个int数中的最大值
# 用户从控制台接收三个整数，通过程序找出三个数中的最大值。
 a = int(input("请输入第一个数字："))
 b = int(input("请输入第二个数字："))
 c = int(input("请输入第三个数字："))
 if  a >= b:
         if  a >= c:
                 print("%d,%d,%d的最大值是%d" % (a, b, c, a))
      else:
         print("%d,%d,%d的最大值是%d" % (a, b, c, c))
  else:
     if  b >= c:
             print("%d,%d,%d的最大值是%d" % (a, b, c, b))
      else:
         print("%d,%d,%d的最大值是%d" % (a, b, c, c))


# 6.数列求和
# 有数列为：9，99，999，...，9999999999。要求使用程序计算此数列的和，并在控制台输出结果。
#  s = 0
 i = 9
 while  i < 10000000000:
         s = s + i
     i = i  *  10 + 9
 print(s)
s = 0
for i in range(1, 11):
    s = s + (10 ** i - 1)



# 7. 有数列：1+1/2+1/3…+1/n（n>=2）。
# 要求使用交互的方式计算此数列的和：用户在控制台录入需要计算的整数 n 的值，程序计算此数列的和，并在控制台输出结果。
 n = int(input("请输入n="))
 s = 0
 for  i  in  range(1, n+1):
         s = s + 1 / i
 print(s)

# 8. 打印九九乘法表
print("我的九九乘法表：")
for i in range(1, 10):
    for j in range(1, i + 1):
        print("%dx%d=%d" % (j, i, j * i), end="\t")
    print("\n")  # 和print()作用一样：换行
# 9. 使用冒泡排序法对下面的列表进行升序排序:
#      [23,8,33,4,88]
list = [23, 8, 33, 4, 88]
n = len(list)
for i in range(n - 1):
    for j in range(n - 1 - i):
        if list[j] > list[j + 1]:
            list[j], list[j + 1] = list[j + 1], list[j]
            # temp = list[j]
            # list[j] = list[j+1]
            # list[j+1] = temp
print(list)

# 比较： 0 :  1
# 比较： 1 :  2
# 比较： 2 :  3
# 比较： 3 :  4
# 比较： 4 :  5
# 比较： 5 :  6
# 比较： 6 :  7

# 比较： 0 :  1
# 比较： 1 :  2
# 比较： 2 :  3
# 比较： 3 :  4
# 比较： 4 :  5
# 比较： 5 :  6

# 比较： 0 :  1
# 比较： 1 :  2
# 比较： 2 :  3
# 比较： 3 :  4
# 比较： 4 :  5

# 比较： 0 :  1
# 比较： 1 :  2
# 比较： 2 :  3
# 比较： 3 :  4

# 比较： 0 :  1
# 比较： 1 :  2
# 比较： 2 :  3

# 比较： 0 :  1
# 比较： 1 :  2

# 比较： 0 :  1