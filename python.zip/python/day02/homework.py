'''
1.计算BMI指数
bmi = 体重（kg）/身高（m）/身高（m）
<18.5  太瘦
18.5-25 正常
25-28 微胖
28-32 肥胖
>32 肥宅


weight = float(input('请输入您的体重啊(kg)：'))
taller = float(input('请输入您的身高(m)：'))
bmi =weight/taller/taller

if bmi<18.5:
    print('太瘦')
elif bmi>=18.5 and bmi<25:
    print('正常')
elif bmi>=25 and bmi<28:
    print('微胖')
elif bmi>=28 and bmi<32:
    print('肥胖')
else:
    print('肥宅')
print("计算完成！")
print('您的bmi是：%.2f'%bmi)


2.定义一个函数，求一元二次方程的解：
    ax*x+bx+c=0

import math
a = float(input('a='))
b = float(input('b='))
c = float(input('c='))
print('a*x*x+b*x+c=0')
m = b*b-4*a*c
if m<0:
    print('无解')
    exit()
else:
    x1=(-b+math.sqrt(m))/(2*a)
    x2=(-b-math.sqrt(m))/(2*a)
print(x1,x2)
'''

# import math
# def result(a,b,c):              # 考虑a=0 ?

#     # 计算delta
#     delta = b*b-4*a*c

#     # 判断delta的值
#     if delta>=0:
#             x1=(-b+math.sqrt(delta))/(2*a)
#             x2=(-b-math.sqrt(delta))/(2*a)

#     else:
#         print('无解')

#     return x1,x2
# r = result(2,3,1)
# print(r)

# x1,x2 = result(2,3,1)
# print(x1,x2)

# 3.输出两个int数中的最大值
# 用户从控制台接收两个整数，通过程序找出两个数中的最大值。控制台的交互效果如图-1所示。
# m = int(input('请输入一个数：'))
# n = int(input('请输入一个数：'))
# if m>n:
#     max = m
#     min = n
# else:
#     max = n
#     min = m
# print('max=%d'%max) 

# 4.编写程序判断某一个年份是否为闰年（使用if-else)
#     本案例需要使用交互的方式判断某年是否为闰年：用户从控制台输入需要判断的年份值，
#     由程序使用if-else判断该年是否为闰年，并将判断结果输出到控制台。
# year = int(input('请输入年份：'))
# def y(year):
#     if year % 400 == 0:
#         return True
#     elif year % 4 == 0 and year % 100 !=0:
#         return True
#     else:
#         return False
# print(y(year))


# 5.输出三个int数中的最大值
# 用户从控制台接收三个整数，通过程序找出三个数中的最大值。
# a = int(input('请输入第一个数：'))
# b = int(input('请输入第二个数：'))
# c = int(input('请输入第三个数：'))
# if a>b and b>c:
#     max = a
# elif b>a and b>c:
#     max = b
# else:
#     max = c    
# print('max=%d'%max)

# 6.数列求和   ???
# 有数列为：9，99，999，...，9999999999。要求使用程序计算此数列的和，并在控制台输出结果。
            # 假如在控制台输入数列项数n

s = 0
i = 9
while i < 1000000000000:
    s = s + i
    i = i * 10 + 9
print(s)

# s = 0
# for i in range(1,11):
#     s = s + (10**i-1)
# print(s)

		


# 7. 有数列：1+1/2+1/3…+1/n（n>=2）。
#     要求使用交互的方式计算此数列的和：用户在控制台录入需要计算的整数 n 的值，程序计算此数列的和，并在控制台输出结果。
# n = int(input('输入整数n：'))
# s = 0
# for i in range(1,n+1):
#     s1 = 1/i
#     s =s + s1
# print(s)


# #8. 打印九九乘法表
# for i in range(1,10):
#     for j in range(1,10):
#         if i <= 9:
#             print(f"{j}*{i}={i*j}",end="\t")
# print("")

# for i in range(1,10):
#     for j in range(1,i+1):
#         print('%d*%d=%d'%(j,i,i*j),end='\t')
#     print()



#9. 使用冒泡排序法对下面的列表进行升序排序:[23,8,33,4,88]      

# def ll():
#     l =[23,8,33,4,88]
#     for j  in range(len(l)-1):
#         for i in range(len(l)-1-j):
#             if l[i] > l[i+1]:
#                 l[i],l[i+1]=l[i+1],l[i]
#     print(l)

# # if __name__ == "__main__":
# #     ll()
# ll()

# 程序 = 算法+数据结构
# 排序：（算法）

