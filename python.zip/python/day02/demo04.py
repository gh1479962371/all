'''
字典dict
key:value
字典是无序的
key是唯一的
value可以重复
和list列表相比：浪费空间、以空间换时间，执行效率高，尤其是在数据量大的时候效率就比list明显
'''

names = ['徐美斌', '白宝蕾', '陈杏梅', '党海斌', '冯凯']
scores = [88, 60, 90, 95, 77]

# 字典
# 字典是无序的
d = {'徐美斌': 88, '白宝蕾': 60, '陈杏梅': 90, '党海斌': 95, '冯凯': 77}
print(d)
# 查询
print(d['徐美斌'])
# GB TB PB
# 添加
d['文杰英'] = 70
print(d)
# 修改
d['白宝蕾'] = 99
print(d)

# 异常
if '徐美兵' in d:  # 查看字典里是否包含一个叫‘徐美兵’的，是则返回True，否则返回False
    print(d['徐美兵'])
print('徐美兵' in d)
print('welcome')
# get()方法获取key对应的value，如果key存在则返回对应的value值；如果key不存在，则返回None
# get()方法和d['徐美斌']形式在key存在时都会返回对应的value值，不存在d['']会报错
print(d.get('徐美斌'))
print(d.get('徐美兵'))
print(d['徐美斌'])
# print(d['徐美兵'])
print('------------end---------------')
# 删除
value = d.pop('徐美斌')  # 返回值是对应的value值，不是key值
print(d)
print(value)

# set
