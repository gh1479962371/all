'''
程序3大结构
    顺序
    分支
    循环
'''

'''分支'''
age = int(input('请输入您的年龄：'))
#  if和else互斥，只能执行一个
if age<18:
    print('您今年是%d岁'%age)
    print('未成年')
elif age<30:
    print('青年')
elif age<60:
    print('中年')
else:
    print('您今年是%d岁'%age)
    print('老年人')

print('鉴定完毕！')

'''
1.计算BMI指数
    bmi = 体重(kg)/身高(m)/身高(m)
    <18.5   太瘦
    18.5-25 正常
    25-28   微胖
    28-32   肥胖
    >32     死肥宅
'''
weight = float(input("请输入您的体重（kg）："))
print(weight)
height = float(input("请输入您的身高（m）："))
bmi = weight/height/height
if bmi<18.5:
    print('太瘦')
elif bmi<25:
    print('正常') 
elif bmi<28:
    print('微胖')
elif bmi<32:
    print('肥胖')
else:
    print('死肥宅')