# 每一个.py文件都是一个模块module
from demo05 import my_abs  # 从demo05模块导入my_abs函数

print(my_abs(-5))