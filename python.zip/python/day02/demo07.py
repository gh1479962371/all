'''
函数的参数
'''
'''
positional argument :位置参数
调用函数时，位置参数必须传参，并且按照形参的位置传递实参
'''
# 求x的n次方《使用循环语句》
# def power(x,n):
#     s = 1
#     for i in range(n):
#         s *= x
#     return s
# print(power(3,3))
# power()  missing 1 required positional argument: 'x'
# print(power())

'''
默认参数:有默认值得参数，调用时可以传参，也可以以不传参
注意：
1.默认参数必须在所有的位置参数后面
2.变化小的参数可以设置默认参数
'''
# def power(x,n=3):
#     s = 1
#     for i in range(n):
#         s = s * x
#     return s
# print(power(3))
# print(power(4,2))

# def person(name,age,gender='男',city='西安'):
#     print(name,age,gender,city)
# person('高换',26,'女''渭南')
# person('赵旭超',28)
# person('赵旭超',28,city='宝鸡')
#位置参数必须在所有默认参数前面
# person(28,city='宝鸡'，'赵旭超')

'''
可变参数:加*
'''
# 3,5,34,22,99,1,6
def s(*digit):   #：*表示各个元素组合成元组
    ss = 0
    for i in digit:
        ss +=i
    return ss
digits = [3,5,6,7,8,9,5]
print(s(*digits))   #：*表示将列表拆分成各个元素
# # print(s([3,5,6,7,8,9,5]))
# print(s(3,5,6,7,8,9,5))

# digits = [3,5,6,7,8,9,5]
# print(s(digits[0],digits[1],digits[2],digits[3],digits[4],digits[5],digits[6]))
# #会报错,因为digits是个列表,之后通过*包装成元组（[]），之后s和digit的值无法计算：int型和列表型
# # print(s(digits))

list1 =['gender'':''女','city'':''渭南']
def student(name,age,*arg):   #:*封装成元组
    print(name,age,*arg)
# student('高换',22,*list1)
student('换换',25,'hh',2521,'gh')



'''
关键字参数
1.参数个数不受限制
2.参数必须以key=vaule的形式出现
'''
def student(name,age,**arg):   #:*封装成字典
    print(name,age,arg)
student('高换',22,gender='女',city='渭南')

'''
可变关键字参数
1.命名关键字参数和位置参数中间要用*隔开
  但是如果有可变参数，则可以不单独写*
'''
def somebody(name,age,*,gender,city):
    print(name,age,gender,city)
somebody('张三',20,gender='男',city='渭南')

def somebody(name,age,*arg,gender,city):  # 如果有可变参数，*可不单独写
    print(name,age,arg,gender,city)
somebody('张三',20,'吃面',gender='男',city='渭南')

'''
参数组合
如果有多种参数类型，注意传参的顺序
'''
# def f(a,b,c=1,*arg,**kw):
#     print(a,b,c,arg,kw)
# # f(1,2,3,4,5,6,name='tom',age=26)
# arg1 = [1,2,3,4,5,6]
# arg2 = {'name':'tom','age':26}
# print('-----------------')
# f(arg1,arg2)
# f(*arg1,**arg2)

# def f2(*arg,**kw):
#     print(arg,kw)
# f2(1,2,3,4,5,6,name='tom',age=26)
# f2(*arg1,**arg2)


