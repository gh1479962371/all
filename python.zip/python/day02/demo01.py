'''
元组tuple
'''

#  定义元组，元组使用（）定义
names = ('徐美斌','白宝蕾','陈杏梅','党海斌','冯凯')
#  元组是不可变的
print(names[0])

# 'tuple' object does not support item assignment
# names[0] = '陆凯利'
# print(names)

# 定义单个元素时，需要加一个,号
t = ('tom')
t1 = ('tom',)
print(t)
print(t1)

# 定义空元组
s = ()
print(s)

# 元组真的不可变吗？
t = ('tom','mike',['julia','jerry'])
print(t)
print(t[2][0])
t[2][0] = 'angle'
print(t[2][0])
print(t)
print(len(t))
